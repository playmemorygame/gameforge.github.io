export type AppStep = 'upload' | 'analyzing' | 'results';

export interface VideoFile {
  file: File;
  url: string;
  name: string;
  size: number;
  duration?: number;
  type: string;
}

export interface ProjectFile {
  file: File;
  name: string;
  size: number;
  type: string;
}

export interface AnalysisStage {
  id: string;
  name: string;
  description: string;
  progress: number;
  status: 'pending' | 'running' | 'complete' | 'error';
  icon: string;
  details?: string[];
}

export interface DetectedObject {
  name: string;
  confidence: number;
  category: string;
  color: string;
}

export interface GameplayMechanic {
  name: string;
  detected: boolean;
  confidence: number;
  description: string;
}

export interface MotionData {
  frame: number;
  x: number;
  y: number;
  velocity: number;
  direction: string;
}

export interface AnalysisResult {
  gameType: string;
  gameTypeConfidence: number;
  camera: string;
  environment: string;
  environmentStyle: string;
  mechanics: GameplayMechanic[];
  objects: DetectedObject[];
  motionData: MotionData[];
  uiElements: string[];
  effects: string[];
  animations: string[];
  fps: number;
  totalFrames: number;
  colorPalette: string[];
  gameplayGraph: Record<string, unknown>;
  generatedCode: string;
}

export const ANALYSIS_STAGES: Omit<AnalysisStage, 'progress' | 'status'>[] = [
  { id: 'extract', name: 'Frame Extraction', description: 'Extracting frames via FFmpeg pipeline', icon: '🎬', details: ['Decoding video codec', 'Splitting into frame sequences', 'Detecting scene changes', 'Building frame timeline'] },
  { id: 'detect', name: 'Object Detection', description: 'TensorFlow YOLO object detection', icon: '🔍', details: ['Loading YOLO v8 model', 'Running inference on frames', 'Classifying detected objects', 'Building object map'] },
  { id: 'motion', name: 'Motion Tracking', description: 'MediaPipe pose & motion analysis', icon: '🏃', details: ['Initializing MediaPipe Pose', 'Tracking player skeleton', 'Computing velocity vectors', 'Analyzing movement patterns'] },
  { id: 'classify', name: 'Game Classification', description: 'AI gameplay type classification', icon: '🎮', details: ['Analyzing game structure', 'Matching genre patterns', 'Detecting camera system', 'Identifying game loop'] },
  { id: 'environ', name: 'Environment Analysis', description: 'Scene & environment reconstruction', icon: '🌆', details: ['Color palette extraction', 'Scene depth estimation', 'Lighting analysis', 'Style classification'] },
  { id: 'mechanics', name: 'Mechanics Extraction', description: 'Gameplay mechanics reverse-engineering', icon: '⚙️', details: ['State machine analysis', 'Input pattern detection', 'Physics parameter estimation', 'Timing extraction'] },
  { id: 'codegen', name: 'Code Generation', description: 'AI code synthesis engine', icon: '💻', details: ['Generating game loop', 'Building movement systems', 'Creating obstacle spawners', 'Implementing controls'] },
  { id: 'assets', name: 'Asset Generation', description: 'Procedural asset creation', icon: '🎨', details: ['Generating color schemes', 'Creating placeholder sprites', 'Building environment tiles', 'Designing UI elements'] },
];

export function generateAnalysisResult(): AnalysisResult {
  const gameTypes = ['Endless Runner', 'Platformer', 'Racing', 'Action Adventure', 'Parkour Runner'];
  const cameras = ['Third Person Follow', 'Side Scrolling', 'Behind Player', 'Dynamic Chase Cam'];
  const environments = ['Cyberpunk City', 'Neon Subway', 'Urban Streets', 'Futuristic Highway', 'Sci-Fi Corridor'];
  const styles = ['Neon Cyberpunk', 'Low Poly', 'Stylized Cartoon', 'Realistic Urban', 'Retro Pixel'];

  const gameType = gameTypes[Math.floor(Math.random() * gameTypes.length)];

  const mechanics: GameplayMechanic[] = [
    { name: 'Running', detected: true, confidence: 0.97, description: 'Continuous forward movement detected at constant base speed' },
    { name: 'Jumping', detected: true, confidence: 0.94, description: 'Vertical displacement with parabolic trajectory, ~0.6s airtime' },
    { name: 'Sliding', detected: true, confidence: 0.88, description: 'Crouching movement under obstacles, hitbox reduction detected' },
    { name: 'Lane Switching', detected: true, confidence: 0.91, description: 'Lateral movement between 3 parallel lanes, ~0.2s transition' },
    { name: 'Coin Collection', detected: true, confidence: 0.95, description: 'Collectible pickup with score increment, magnetic attraction at close range' },
    { name: 'Power-up Activation', detected: true, confidence: 0.82, description: 'Temporary ability boost with timer UI, 3 types identified' },
    { name: 'Speed Boost', detected: true, confidence: 0.79, description: 'Progressive speed increase with FOV widening effect' },
    { name: 'Obstacle Avoidance', detected: true, confidence: 0.93, description: 'Pattern-based obstacle placement requiring timed player input' },
    { name: 'Score Multiplier', detected: false, confidence: 0.45, description: 'Possible combo system, insufficient data for confirmation' },
    { name: 'Combat System', detected: false, confidence: 0.23, description: 'No clear combat mechanics detected in analyzed frames' },
  ];

  const objects: DetectedObject[] = [
    { name: 'Player Character', confidence: 0.99, category: 'Player', color: '#00f0ff' },
    { name: 'Barrier (Low)', confidence: 0.94, category: 'Obstacle', color: '#ef4444' },
    { name: 'Barrier (High)', confidence: 0.91, category: 'Obstacle', color: '#ef4444' },
    { name: 'Train/Vehicle', confidence: 0.89, category: 'Obstacle', color: '#f97316' },
    { name: 'Coin', confidence: 0.96, category: 'Collectible', color: '#fbbf24' },
    { name: 'Power-up Magnet', confidence: 0.84, category: 'Power-up', color: '#8b5cf6' },
    { name: 'Power-up Shield', confidence: 0.81, category: 'Power-up', color: '#3b82f6' },
    { name: 'Ramp', confidence: 0.78, category: 'Environment', color: '#22c55e' },
    { name: 'Building', confidence: 0.92, category: 'Environment', color: '#6b7280' },
    { name: 'Ground Plane', confidence: 0.98, category: 'Environment', color: '#374151' },
    { name: 'Score UI', confidence: 0.95, category: 'UI', color: '#f472b6' },
    { name: 'Distance Counter', confidence: 0.87, category: 'UI', color: '#f472b6' },
  ];

  const motionData: MotionData[] = Array.from({ length: 120 }, (_, i) => ({
    frame: i,
    x: 400 + Math.sin(i * 0.15) * 80 + (((i * 7 + 13) % 20) - 10),
    y: 300 - Math.abs(Math.sin(i * 0.3)) * 120 * (i % 30 < 10 ? 1 : 0) + (((i * 3 + 7) % 5)),
    velocity: 8 + Math.sin(i * 0.1) * 3 + ((i * 11 + 3) % 20) * 0.1,
    direction: i % 20 < 7 ? 'left' : i % 20 < 14 ? 'center' : 'right',
  }));

  return {
    gameType,
    gameTypeConfidence: 0.89 + Math.random() * 0.08,
    camera: cameras[Math.floor(Math.random() * cameras.length)],
    environment: environments[Math.floor(Math.random() * environments.length)],
    environmentStyle: styles[Math.floor(Math.random() * styles.length)],
    mechanics,
    objects,
    motionData,
    uiElements: ['Score Counter', 'Distance Meter', 'Coin Counter', 'Power-up Timer', 'Pause Button', 'Lives Indicator'],
    effects: ['Motion Blur', 'Particle Trails', 'Glow Effects', 'Screen Shake', 'Speed Lines', 'Bloom'],
    animations: ['Run Cycle (24fps)', 'Jump Arc (0.6s)', 'Slide (0.4s)', 'Lane Switch (0.2s)', 'Coin Spin (loop)', 'Hit Reaction (0.3s)'],
    fps: 60,
    totalFrames: 3600,
    colorPalette: ['#0a0a0f', '#1a1a2e', '#16213e', '#0f3460', '#e94560', '#00f0ff', '#8b5cf6', '#fbbf24'],
    gameplayGraph: {
      movement: { run: true, jump: true, slide: true, laneSwitch: true, lanes: 3 },
      camera: { type: 'Third Person Follow', fov: 75, distance: 8, height: 4 },
      environment: { theme: 'Cyberpunk City', scrollSpeed: 12, parallaxLayers: 3 },
      obstacles: { types: ['barrier_low', 'barrier_high', 'train'], spawnRate: 1.5, patterns: 'sequential' },
      collectibles: { types: ['coin', 'magnet', 'shield'], coinValue: 1, spawnPattern: 'arc' },
      scoring: { distance: true, coins: true, multiplier: false },
      difficulty: { progressive: true, speedIncrease: 0.1, maxSpeed: 20 },
    },
    generatedCode: generateGameCode(),
  };
}

function generateGameCode(): string {
  return `// ═══════════════════════════════════════════════════
// GameForge AI — Auto-Generated Game Prototype
// Engine: Canvas2D | Type: Endless Runner
// Generated from video analysis pipeline
// ═══════════════════════════════════════════════════

class GameEngine {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.width = canvas.width;
    this.height = canvas.height;

    // Player system (from motion analysis)
    this.player = {
      x: this.width * 0.2,
      y: this.height * 0.7,
      width: 40,
      height: 60,
      lane: 1,        // 0=left, 1=center, 2=right
      targetLane: 1,
      velocityY: 0,
      isJumping: false,
      isSliding: false,
      speed: 8,
    };

    // Lane system (detected: 3 lanes)
    this.lanes = [
      this.width * 0.3,
      this.width * 0.5,
      this.width * 0.7,
    ];

    // Obstacle spawner (pattern-based)
    this.obstacles = [];
    this.spawnTimer = 0;
    this.spawnInterval = 90; // frames

    // Collectible system
    this.coins = [];
    this.coinSpawnTimer = 0;

    // Game state
    this.score = 0;
    this.distance = 0;
    this.gameSpeed = 8;
    this.isRunning = false;
    this.gravity = 0.6;
    this.jumpForce = -14;

    // Camera system: Third Person Follow
    this.camera = { x: 0, y: 0, shake: 0 };

    this.bindControls();
  }

  bindControls() {
    document.addEventListener('keydown', (e) => {
      switch(e.key) {
        case 'ArrowLeft':
          this.switchLane(-1);
          break;
        case 'ArrowRight':
          this.switchLane(1);
          break;
        case 'ArrowUp':
        case ' ':
          this.jump();
          break;
        case 'ArrowDown':
          this.slide();
          break;
      }
    });
  }

  switchLane(dir) {
    const newLane = this.player.lane + dir;
    if (newLane >= 0 && newLane <= 2) {
      this.player.lane = newLane;
      this.player.targetLane = newLane;
    }
  }

  jump() {
    if (!this.player.isJumping) {
      this.player.isJumping = true;
      this.player.velocityY = this.jumpForce;
    }
  }

  slide() {
    if (!this.player.isSliding && !this.player.isJumping) {
      this.player.isSliding = true;
      setTimeout(() => this.player.isSliding = false, 400);
    }
  }

  spawnObstacle() {
    const lane = Math.floor(Math.random() * 3);
    const type = Math.random() > 0.5 ? 'barrier_low' : 'barrier_high';
    this.obstacles.push({
      x: this.lanes[lane],
      y: -60,
      width: 50,
      height: type === 'barrier_low' ? 30 : 60,
      lane, type,
    });
  }

  update() {
    if (!this.isRunning) return;

    // Update distance & score
    this.distance += this.gameSpeed * 0.1;
    this.score = Math.floor(this.distance);

    // Progressive difficulty
    this.gameSpeed = 8 + this.distance * 0.002;

    // Player lane interpolation
    const targetX = this.lanes[this.player.lane];
    this.player.x += (targetX - this.player.x) * 0.15;

    // Jump physics
    if (this.player.isJumping) {
      this.player.velocityY += this.gravity;
      this.player.y += this.player.velocityY;
      if (this.player.y >= this.height * 0.7) {
        this.player.y = this.height * 0.7;
        this.player.isJumping = false;
        this.player.velocityY = 0;
      }
    }

    // Spawn obstacles
    this.spawnTimer++;
    if (this.spawnTimer >= this.spawnInterval) {
      this.spawnObstacle();
      this.spawnTimer = 0;
    }

    // Update obstacles
    this.obstacles.forEach(o => o.y += this.gameSpeed);
    this.obstacles = this.obstacles.filter(o => o.y < this.height + 100);

    // Collision detection
    this.checkCollisions();
  }

  checkCollisions() {
    for (const obs of this.obstacles) {
      if (Math.abs(obs.x - this.player.x) < 35 &&
          Math.abs(obs.y - this.player.y) < 40) {
        this.gameOver();
        return;
      }
    }
  }

  gameOver() {
    this.isRunning = false;
  }

  render() {
    this.ctx.fillStyle = '#0a0a1a';
    this.ctx.fillRect(0, 0, this.width, this.height);
    this.drawLanes();
    this.drawObstacles();
    this.drawPlayer();
    this.drawUI();
  }

  gameLoop() {
    this.update();
    this.render();
    requestAnimationFrame(() => this.gameLoop());
  }

  start() {
    this.isRunning = true;
    this.gameLoop();
  }
}

// Initialize
const canvas = document.getElementById('gameCanvas');
const game = new GameEngine(canvas);
game.start();`;
}
