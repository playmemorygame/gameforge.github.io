import { useEffect, useRef, useCallback, useState, useMemo } from 'react';
import type { AnalysisResult } from '../types';

interface Props { result: AnalysisResult; }

// ── Seeded pseudo-random for deterministic scenery ──
function seeded(s: number) { return () => { s = (s * 16807 + 0) % 2147483647; return (s - 1) / 2147483646; }; }

export default function GamePreview({ result }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<any>(null);
  const keysRef = useRef<Set<string>>(new Set());
  const touchRef = useRef<{ x: number; y: number } | null>(null);
  const [score, setScore] = useState(0);
  const [coinCount, setCoinCount] = useState(0);
  const [combo, setCombo] = useState(0);
  const [distance, setDistance] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [started, setStarted] = useState(false);
  const [highScore, setHighScore] = useState(0);

  const W = 900;
  const H = 560;

  // ── Stable scenery data ──
  const scenery = useMemo(() => {
    const r = seeded(42);
    return {
      stars: Array.from({ length: 80 }, () => ({
        x: r() * W, y: r() * H * 0.35, s: 0.5 + r() * 2, phase: r() * Math.PI * 2, brightness: 0.3 + r() * 0.5,
      })),
      bgBuildings: Array.from({ length: 30 }, () => ({
        x: r() * W * 2, h: 40 + r() * 160, w: 20 + r() * 50,
        hue: 220 + r() * 30, light: 5 + r() * 8,
        windows: Array.from({ length: 20 }, () => r() > 0.4),
        antenna: r() > 0.6, antennaH: 10 + r() * 30,
      })),
      fgBuildings: Array.from({ length: 20 }, () => ({
        x: r() * W * 2, h: 60 + r() * 220, w: 35 + r() * 70,
        hue: 225 + r() * 25, light: 3 + r() * 6,
        windows: Array.from({ length: 30 }, () => r() > 0.35),
        ledge: r() > 0.5, ledgeH: r() * 0.4,
      })),
      clouds: Array.from({ length: 6 }, () => ({
        x: r() * W * 2, y: 20 + r() * 60, w: 80 + r() * 120, h: 15 + r() * 25, speed: 0.1 + r() * 0.3,
      })),
    };
  }, []);

  // ── State factory ──
  function createState() {
    const laneW = 72;
    const laneX = [W / 2 - laneW, W / 2, W / 2 + laneW];
    const groundY = H * 0.82;
    return {
      // Player
      px: laneX[1], py: groundY, lane: 1, targetLane: 1,
      vy: 0, jumping: false, sliding: false, slideTimer: 0,
      invincible: 0, magnetTimer: 0, doubleTimer: 0, shieldHits: 0,
      tilt: 0, squash: 1, stretch: 1, runPhase: 0,
      // World
      laneX, laneW, groundY,
      obstacles: [] as any[], coinList: [] as any[], powerups: [] as any[],
      particles: [] as any[], floatingTexts: [] as any[],
      // Scoring
      score: 0, coinCount: 0, combo: 0, comboTimer: 0, multiplier: 1, distance: 0,
      // Timing
      speed: 6, maxSpeed: 22, frame: 0,
      spawnTimer: 0, coinSpawnTimer: 0, powerupTimer: 0,
      running: true, gridOffset: 0,
      // FX
      shakeX: 0, shakeY: 0, shakeMag: 0,
      flashAlpha: 0, flashColor: '#fff',
      fovStretch: 0,
      // Difficulty
      difficultyWave: 0,
      lastObstacleLanes: [] as number[],
    };
  }

  const initGame = useCallback(() => {
    gameRef.current = createState();
    setGameOver(false);
    setStarted(true);
    setScore(0); setCoinCount(0); setCombo(0); setDistance(0);
  }, []);

  // ── Input ──
  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      keysRef.current.add(e.key);
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', ' '].includes(e.key)) e.preventDefault();
    };
    const up = (e: KeyboardEvent) => keysRef.current.delete(e.key);
    window.addEventListener('keydown', down);
    window.addEventListener('keyup', up);
    return () => { window.removeEventListener('keydown', down); window.removeEventListener('keyup', up); };
  }, []);

  // ── Touch / swipe ──
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ts = (e: TouchEvent) => { e.preventDefault(); touchRef.current = { x: e.touches[0].clientX, y: e.touches[0].clientY }; };
    const te = (e: TouchEvent) => {
      if (!touchRef.current || !gameRef.current) return;
      const dx = e.changedTouches[0].clientX - touchRef.current.x;
      const dy = e.changedTouches[0].clientY - touchRef.current.y;
      const s = gameRef.current;
      if (Math.abs(dx) > Math.abs(dy)) {
        if (dx > 30 && s.lane < 2) { s.targetLane = s.lane + 1; }
        else if (dx < -30 && s.lane > 0) { s.targetLane = s.lane - 1; }
      } else {
        if (dy < -30 && !s.jumping) { s.jumping = true; s.vy = -15.5; }
        else if (dy > 30 && !s.sliding && !s.jumping) { s.sliding = true; s.slideTimer = 30; }
      }
      touchRef.current = null;
    };
    canvas.addEventListener('touchstart', ts, { passive: false });
    canvas.addEventListener('touchend', te);
    return () => { canvas.removeEventListener('touchstart', ts); canvas.removeEventListener('touchend', te); };
  }, []);

  // ════════════════════════════════════════
  //  MAIN GAME LOOP
  // ════════════════════════════════════════
  useEffect(() => {
    if (!started) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d')!;
    let animId: number;
    let lastTime = performance.now();

    const addParticle = (s: any, x: number, y: number, vx: number, vy: number, color: string, size: number, life: number, glow = false) => {
      s.particles.push({ x, y, vx, vy, color, size, life, maxLife: life, glow });
    };

    const addFloatText = (s: any, x: number, y: number, text: string, color: string) => {
      s.floatingTexts.push({ x, y, text, color, life: 60, vy: -2 });
    };

    const spawnCoinPattern = (s: any, lane: number, pattern: string) => {
      const baseY = -40;
      const sp = 38;
      if (pattern === 'line') {
        for (let i = 0; i < 5; i++) s.coinList.push({ x: s.laneX[lane], y: baseY - i * sp, lane, collected: false, angle: 0, magnet: false });
      } else if (pattern === 'arc') {
        for (let i = 0; i < 5; i++) {
          const arcY = -Math.sin((i / 4) * Math.PI) * 60;
          s.coinList.push({ x: s.laneX[lane], y: baseY - i * sp + arcY, lane, collected: false, angle: i * 0.3, magnet: false });
        }
      } else if (pattern === 'cross') {
        for (let l = 0; l < 3; l++) {
          s.coinList.push({ x: s.laneX[l], y: baseY, lane: l, collected: false, angle: 0, magnet: false });
        }
        s.coinList.push({ x: s.laneX[1], y: baseY - sp, lane: 1, collected: false, angle: 0, magnet: false });
        s.coinList.push({ x: s.laneX[1], y: baseY - sp * 2, lane: 1, collected: false, angle: 0, magnet: false });
      } else { // diamond
        const mid = 1;
        s.coinList.push({ x: s.laneX[mid], y: baseY, lane: mid, collected: false, angle: 0, magnet: false });
        s.coinList.push({ x: s.laneX[0], y: baseY - sp, lane: 0, collected: false, angle: 0, magnet: false });
        s.coinList.push({ x: s.laneX[2], y: baseY - sp, lane: 2, collected: false, angle: 0, magnet: false });
        s.coinList.push({ x: s.laneX[mid], y: baseY - sp * 2, lane: mid, collected: false, angle: 0, magnet: false });
      }
    };

    const loop = (now: number) => {
      const dt = Math.min((now - lastTime) / 16.667, 2.5); // normalize to ~60fps
      lastTime = now;
      const s = gameRef.current;
      if (!s) return;

      // ── INPUT ──
      const keys = keysRef.current;
      if ((keys.has('ArrowLeft') || keys.has('a')) && s.running) {
        if (s.lane > 0) { s.targetLane = s.lane - 1; s.tilt = -0.2; }
        keys.delete('ArrowLeft'); keys.delete('a');
      }
      if ((keys.has('ArrowRight') || keys.has('d')) && s.running) {
        if (s.lane < 2) { s.targetLane = s.lane + 1; s.tilt = 0.2; }
        keys.delete('ArrowRight'); keys.delete('d');
      }
      if ((keys.has('ArrowUp') || keys.has('w') || keys.has(' ')) && !s.jumping && s.running) {
        s.jumping = true; s.vy = -15.5; s.squash = 0.6; s.stretch = 1.3;
        for (let i = 0; i < 8; i++) addParticle(s, s.px, s.groundY + 10, (Math.random() - 0.5) * 6, -Math.random() * 4 - 1, '#00f0ff', 2 + Math.random() * 3, 25, true);
        keys.delete('ArrowUp'); keys.delete('w'); keys.delete(' ');
      }
      if ((keys.has('ArrowDown') || keys.has('s')) && !s.sliding && !s.jumping && s.running) {
        s.sliding = true; s.slideTimer = 30; s.squash = 1.4; s.stretch = 0.5;
        for (let i = 0; i < 6; i++) addParticle(s, s.px + (Math.random() - 0.5) * 30, s.groundY + 5, (Math.random() - 0.5) * 3, -Math.random() * 2, 'rgba(0,240,255,0.4)', 3, 15);
        keys.delete('ArrowDown'); keys.delete('s');
      }
      if (keys.has('Enter') && !s.running) { initGame(); keys.delete('Enter'); }

      // ── UPDATE ──
      if (s.running) {
        s.frame++;
        s.runPhase += s.speed * 0.04 * dt;

        // Difficulty waves
        s.difficultyWave = Math.floor(s.distance / 500);
        s.speed = Math.min(s.maxSpeed, 6 + s.distance * 0.004 + Math.sin(s.frame * 0.005) * 0.5);
        s.score += s.speed * 0.2 * s.multiplier * dt;
        s.distance += s.speed * 0.15 * dt;
        s.gridOffset = (s.gridOffset + s.speed * dt) % 80;
        s.fovStretch += (Math.min(1, (s.speed - 6) / 16) * 0.15 - s.fovStretch) * 0.03;

        // Combo decay
        if (s.comboTimer > 0) { s.comboTimer -= dt; }
        else if (s.combo > 0) { s.combo = 0; s.multiplier = 1; }

        // Power-up timers
        if (s.invincible > 0) s.invincible -= dt;
        if (s.magnetTimer > 0) s.magnetTimer -= dt;
        if (s.doubleTimer > 0) { s.doubleTimer -= dt; } else if (s.multiplier > 1 && s.combo === 0) { s.multiplier = 1; }

        // Lane switching (smooth easing)
        if (s.targetLane !== s.lane) {
          const diff = s.targetLane - s.lane;
          s.lane += diff;
        }
        const targetX = s.laneX[s.lane];
        const lerpSpeed = 0.14 * dt;
        s.px += (targetX - s.px) * Math.min(lerpSpeed, 1);
        s.tilt += (0 - s.tilt) * 0.08 * dt;
        s.squash += (1 - s.squash) * 0.1 * dt;
        s.stretch += (1 - s.stretch) * 0.1 * dt;

        // Jump physics
        if (s.jumping) {
          s.vy += 0.72 * dt;
          s.py += s.vy * dt;
          if (s.py >= s.groundY) {
            s.py = s.groundY; s.jumping = false; s.vy = 0;
            s.squash = 1.3; s.stretch = 0.7;
            for (let i = 0; i < 10; i++) addParticle(s, s.px + (Math.random() - 0.5) * 24, s.groundY + 8, (Math.random() - 0.5) * 5, -Math.random() * 3 - 1, '#00f0ff', 2 + Math.random() * 3, 20, true);
          }
        }

        // Slide
        if (s.sliding) { s.slideTimer -= dt; if (s.slideTimer <= 0) { s.sliding = false; s.squash = 0.8; s.stretch = 1.15; } }

        // ── SPAWNING ──
        s.spawnTimer += dt;
        const spawnRate = Math.max(28, 65 - s.speed * 1.8 - s.difficultyWave * 2);
        if (s.spawnTimer >= spawnRate) {
          s.spawnTimer = 0;
          // Ensure at least 1 lane is always open
          const lane1 = Math.floor(Math.random() * 3);
          const obstTypes: any[] = [
            { type: 'barrier', w: 58, h: 28, color: '#ef4444' },
            { type: 'tall', w: 48, h: 62, color: '#f97316' },
            { type: 'train', w: 64, h: 80, color: '#6366f1' },
            { type: 'spike', w: 36, h: 40, color: '#ec4899' },
          ];
          const availTypes = s.difficultyWave < 1 ? obstTypes.slice(0, 2) : s.difficultyWave < 3 ? obstTypes.slice(0, 3) : obstTypes;
          const t1 = availTypes[Math.floor(Math.random() * availTypes.length)];
          s.obstacles.push({ x: s.laneX[lane1], y: -80, ...t1, lane: lane1, passed: false });

          // Double obstacle (leave 1 lane open)
          if (Math.random() < 0.35 + s.difficultyWave * 0.05) {
            const openLanes = [0, 1, 2].filter(l => l !== lane1);
            const lane2 = openLanes[Math.floor(Math.random() * openLanes.length)];
            const t2 = availTypes[Math.floor(Math.random() * availTypes.length)];
            s.obstacles.push({ x: s.laneX[lane2], y: -80, ...t2, lane: lane2, passed: false });
          }
        }

        // Coins
        s.coinSpawnTimer += dt;
        if (s.coinSpawnTimer >= 40) {
          s.coinSpawnTimer = 0;
          const patterns = ['line', 'arc', 'cross', 'diamond'];
          const pat = patterns[Math.floor(Math.random() * patterns.length)];
          const lane = Math.floor(Math.random() * 3);
          spawnCoinPattern(s, lane, pat);
        }

        // Powerups
        s.powerupTimer += dt;
        if (s.powerupTimer >= 300 + Math.random() * 200) {
          s.powerupTimer = 0;
          const pTypes = ['magnet', 'shield', 'double', 'star'];
          const pt = pTypes[Math.floor(Math.random() * pTypes.length)];
          const lane = Math.floor(Math.random() * 3);
          s.powerups.push({ x: s.laneX[lane], y: -50, lane, type: pt, angle: 0, collected: false, bobPhase: Math.random() * Math.PI * 2 });
        }

        // ── MOVE ENTITIES ──
        for (const o of s.obstacles) o.y += s.speed * dt;
        s.obstacles = s.obstacles.filter((o: any) => o.y < H + 100);
        for (const c of s.coinList) { c.y += s.speed * dt; c.angle += 0.08 * dt; }
        s.coinList = s.coinList.filter((c: any) => c.y < H + 50 && !c.collected);
        for (const p of s.powerups) { p.y += s.speed * dt; p.angle += 0.05 * dt; p.bobPhase += 0.07 * dt; }
        s.powerups = s.powerups.filter((p: any) => p.y < H + 50 && !p.collected);

        // ── MAGNET ──
        if (s.magnetTimer > 0) {
          for (const c of s.coinList) {
            if (c.collected) continue;
            const dx = s.px - c.x; const dy = s.py - c.y;
            const dist = Math.sqrt(dx * dx + dy * dy);
            if (dist < 180) {
              c.x += (dx / dist) * 8 * dt;
              c.y += (dy / dist) * 8 * dt;
              c.magnet = true;
            }
          }
        }

        // ── COIN COLLECTION ──
        const playerH = s.sliding ? 20 : 52;
        const playerW = 28;
        const playerCY = s.sliding ? s.py : s.py - 16;
        for (const c of s.coinList) {
          if (c.collected) continue;
          if (Math.abs(c.x - s.px) < playerW + 12 && Math.abs(c.y - playerCY) < playerH / 2 + 12) {
            c.collected = true;
            const val = s.doubleTimer > 0 ? 2 : 1;
            s.coinCount += val;
            s.combo++;
            s.comboTimer = 90;
            s.multiplier = Math.min(8, 1 + Math.floor(s.combo / 5));
            for (let i = 0; i < 6; i++) addParticle(s, c.x, c.y, (Math.random() - 0.5) * 6, (Math.random() - 0.5) * 6, '#fbbf24', 3 + Math.random() * 3, 20, true);
            addFloatText(s, c.x, c.y - 20, `+${val}`, '#fbbf24');
            if (s.combo > 0 && s.combo % 5 === 0) {
              addFloatText(s, s.px, s.py - 60, `${s.multiplier}x COMBO!`, '#f472b6');
              s.flashAlpha = 0.15; s.flashColor = '#f472b6';
            }
          }
        }
        // Fix coins counter (it's an array name collision, use coinCount)
        // coinCount tracked on s.coinCount directly

        // ── POWERUP COLLECTION ──
        for (const p of s.powerups) {
          if (p.collected) continue;
          if (Math.abs(p.x - s.px) < playerW + 16 && Math.abs(p.y - playerCY) < playerH / 2 + 16) {
            p.collected = true;
            s.flashAlpha = 0.2;
            for (let i = 0; i < 15; i++) addParticle(s, p.x, p.y, (Math.random() - 0.5) * 10, (Math.random() - 0.5) * 10, '#a78bfa', 3 + Math.random() * 4, 30, true);
            if (p.type === 'magnet') { s.magnetTimer = 300; s.flashColor = '#3b82f6'; addFloatText(s, p.x, p.y - 30, 'MAGNET!', '#3b82f6'); }
            else if (p.type === 'shield') { s.shieldHits = 1; s.flashColor = '#22d3ee'; addFloatText(s, p.x, p.y - 30, 'SHIELD!', '#22d3ee'); }
            else if (p.type === 'double') { s.doubleTimer = 300; s.multiplier = Math.max(s.multiplier, 2); s.flashColor = '#fbbf24'; addFloatText(s, p.x, p.y - 30, '2X COINS!', '#fbbf24'); }
            else if (p.type === 'star') { s.invincible = 180; s.flashColor = '#f472b6'; addFloatText(s, p.x, p.y - 30, 'STAR!', '#f472b6'); }
          }
        }

        // ── NEAR-MISS & COLLISION ──
        for (const o of s.obstacles) {
          const ox = o.x, oy = o.y, ow = o.w, oh = o.h;
          const dx = Math.abs(ox - s.px);
          const dy = Math.abs(oy - playerCY);
          const hitW = ow / 2 + playerW / 2 - 6;
          const hitH = oh / 2 + playerH / 2 - 6;

          // Near miss detection
          if (!o.passed && oy > s.py + 10) {
            o.passed = true;
            if (dx < hitW + 30 && dx >= hitW) {
              s.score += 25 * s.multiplier;
              addFloatText(s, s.px, s.py - 50, 'NEAR MISS! +25', '#4ade80');
              s.combo += 2; s.comboTimer = 90;
            }
          }

          if (dx < hitW && dy < hitH) {
            // Slide under tall/spike
            if (s.sliding && (o.type === 'tall' || o.type === 'spike')) continue;
            // Jump over barrier
            if (s.jumping && s.py < s.groundY - 50 && o.type === 'barrier') continue;
            // Invincible
            if (s.invincible > 0) {
              o.y = H + 200; // remove
              s.score += 50; s.shakeMag = 8;
              for (let i = 0; i < 12; i++) addParticle(s, ox, oy, (Math.random() - 0.5) * 12, (Math.random() - 0.5) * 12, '#f472b6', 4, 25, true);
              addFloatText(s, ox, oy - 20, 'SMASH! +50', '#f472b6');
              continue;
            }
            // Shield
            if (s.shieldHits > 0) {
              s.shieldHits--; o.y = H + 200;
              s.shakeMag = 12; s.flashAlpha = 0.3; s.flashColor = '#22d3ee';
              for (let i = 0; i < 15; i++) addParticle(s, ox, oy, (Math.random() - 0.5) * 10, (Math.random() - 0.5) * 10, '#22d3ee', 4, 25, true);
              addFloatText(s, s.px, s.py - 50, 'SHIELD BREAK!', '#22d3ee');
              continue;
            }

            // DEATH
            s.running = false; s.shakeMag = 25;
            s.flashAlpha = 0.6; s.flashColor = '#ef4444';
            for (let i = 0; i < 40; i++) {
              const a = (i / 40) * Math.PI * 2;
              const spd = 3 + Math.random() * 8;
              addParticle(s, s.px, s.py - 16, Math.cos(a) * spd, Math.sin(a) * spd - 3, i % 3 === 0 ? '#ef4444' : i % 3 === 1 ? '#f97316' : '#fbbf24', 3 + Math.random() * 5, 40 + Math.random() * 20, true);
            }
            setGameOver(true);
            setHighScore(prev => Math.max(prev, Math.floor(s.score)));
            break;
          }
        }

        // ── PARTICLES & FLOATING TEXT ──
        for (const p of s.particles) { p.x += p.vx * dt; p.y += p.vy * dt; p.vy += 0.15 * dt; p.life -= dt; }
        s.particles = s.particles.filter((p: any) => p.life > 0);
        for (const ft of s.floatingTexts) { ft.y += ft.vy * dt; ft.life -= dt; }
        s.floatingTexts = s.floatingTexts.filter((ft: any) => ft.life > 0);

        // Screen shake decay
        s.shakeMag *= 0.88;
        if (s.shakeMag < 0.3) s.shakeMag = 0;
        s.shakeX = (Math.random() - 0.5) * s.shakeMag;
        s.shakeY = (Math.random() - 0.5) * s.shakeMag;
        s.flashAlpha *= 0.92;

        // Running trail particles
        if (s.frame % 2 === 0 && !s.jumping) {
          addParticle(s, s.px + (Math.random() - 0.5) * 10, s.groundY + 8 + Math.random() * 4, (Math.random() - 0.5) * 1.5, Math.random() * 1.5 + 0.5, 'rgba(0,240,255,0.3)', 1.5 + Math.random() * 2, 12);
        }

        // Sync React state (throttled)
        if (s.frame % 6 === 0) {
          setScore(Math.floor(s.score));
          // Recount coins properly
          setCoinCount(s.coinCount);
          setCombo(s.combo);
          setDistance(Math.floor(s.distance));
        }
      } else {
        // Dead — still update particles
        for (const p of s.particles) { p.x += p.vx * dt; p.y += p.vy * dt; p.vy += 0.15 * dt; p.life -= dt; }
        s.particles = s.particles.filter((p: any) => p.life > 0);
        s.shakeMag *= 0.92;
        s.shakeX = (Math.random() - 0.5) * s.shakeMag;
        s.shakeY = (Math.random() - 0.5) * s.shakeMag;
        s.flashAlpha *= 0.95;
      }

      // ═══════════════════════════════════════
      //  RENDER
      // ═══════════════════════════════════════
      ctx.save();
      ctx.translate(s.shakeX, s.shakeY);

      // Sky gradient
      const skyGrad = ctx.createLinearGradient(0, 0, 0, H);
      skyGrad.addColorStop(0, '#020210');
      skyGrad.addColorStop(0.25, '#06061a');
      skyGrad.addColorStop(0.55, '#0c0c28');
      skyGrad.addColorStop(1, '#10102a');
      ctx.fillStyle = skyGrad;
      ctx.fillRect(-20, -20, W + 40, H + 40);

      // Aurora / nebula glow
      const auroraGrad = ctx.createRadialGradient(W * 0.3, H * 0.15, 0, W * 0.3, H * 0.15, 250);
      auroraGrad.addColorStop(0, 'rgba(139,92,246,0.06)');
      auroraGrad.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = auroraGrad;
      ctx.fillRect(0, 0, W, H * 0.5);
      const auroraGrad2 = ctx.createRadialGradient(W * 0.75, H * 0.1, 0, W * 0.75, H * 0.1, 200);
      auroraGrad2.addColorStop(0, 'rgba(0,240,255,0.04)');
      auroraGrad2.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = auroraGrad2;
      ctx.fillRect(0, 0, W, H * 0.5);

      // Stars
      for (const st of scenery.stars) {
        const b = st.brightness * (0.5 + Math.sin(s.frame * 0.015 + st.phase) * 0.5);
        ctx.fillStyle = `rgba(200,220,255,${b})`;
        ctx.beginPath(); ctx.arc(st.x, st.y, st.s, 0, Math.PI * 2); ctx.fill();
      }

      // Clouds
      for (const cl of scenery.clouds) {
        const cx = ((cl.x - s.frame * cl.speed) % (W + 200) + W + 200) % (W + 200) - 100;
        ctx.fillStyle = 'rgba(100,120,180,0.03)';
        ctx.beginPath();
        ctx.ellipse(cx, cl.y, cl.w / 2, cl.h / 2, 0, 0, Math.PI * 2);
        ctx.fill();
      }

      const gLine = s.groundY + 14;

      // Background buildings (far)
      for (const b of scenery.bgBuildings) {
        const bx = ((b.x - s.frame * 0.3) % (W + 200) + W + 200) % (W + 200) - 100;
        ctx.fillStyle = `hsla(${b.hue}, 30%, ${b.light}%, 0.7)`;
        ctx.fillRect(bx, gLine - b.h, b.w, b.h);
        if (b.antenna) {
          ctx.strokeStyle = 'rgba(0,240,255,0.2)'; ctx.lineWidth = 1;
          ctx.beginPath(); ctx.moveTo(bx + b.w / 2, gLine - b.h); ctx.lineTo(bx + b.w / 2, gLine - b.h - b.antennaH); ctx.stroke();
          ctx.fillStyle = `rgba(255,50,50,${0.5 + Math.sin(s.frame * 0.1) * 0.5})`;
          ctx.beginPath(); ctx.arc(bx + b.w / 2, gLine - b.h - b.antennaH, 2, 0, Math.PI * 2); ctx.fill();
        }
        let wi = 0;
        for (let wy = 0; wy < Math.min(6, Math.floor(b.h / 22)); wy++) {
          for (let wx = 0; wx < Math.min(3, Math.floor(b.w / 14)); wx++) {
            if (b.windows[wi % b.windows.length]) {
              ctx.fillStyle = `rgba(0,240,255,${0.08 + Math.sin(s.frame * 0.01 + wi) * 0.04})`;
              ctx.fillRect(bx + 4 + wx * 13, gLine - b.h + 8 + wy * 22, 5, 8);
            }
            wi++;
          }
        }
      }

      // Foreground buildings (near)
      for (const b of scenery.fgBuildings) {
        const bx = ((b.x - s.frame * 0.8) % (W + 200) + W + 200) % (W + 200) - 100;
        ctx.fillStyle = `hsla(${b.hue}, 35%, ${b.light}%, 0.9)`;
        ctx.fillRect(bx, gLine - b.h, b.w, b.h);
        if (b.ledge) {
          ctx.fillStyle = `hsla(${b.hue}, 30%, ${b.light + 2}%, 0.9)`;
          ctx.fillRect(bx - 3, gLine - b.h * b.ledgeH, b.w + 6, 4);
        }
        let wi = 0;
        for (let wy = 0; wy < Math.min(8, Math.floor(b.h / 18)); wy++) {
          for (let wx = 0; wx < Math.min(4, Math.floor(b.w / 12)); wx++) {
            if (b.windows[wi % b.windows.length]) {
              const glow = 0.12 + Math.sin(s.frame * 0.008 + wi * 0.7) * 0.08;
              ctx.fillStyle = `rgba(0,200,255,${glow})`;
              ctx.fillRect(bx + 4 + wx * 12, gLine - b.h + 6 + wy * 18, 5, 8);
            }
            wi++;
          }
        }
      }

      // ── GROUND PLANE WITH PERSPECTIVE ──
      const groundGrad = ctx.createLinearGradient(0, gLine, 0, H);
      groundGrad.addColorStop(0, '#12122e');
      groundGrad.addColorStop(0.3, '#0e0e24');
      groundGrad.addColorStop(1, '#08081a');
      ctx.fillStyle = groundGrad;
      ctx.fillRect(0, gLine, W, H);

      // Perspective grid (horizontal lines receding)
      for (let i = 0; i < 20; i++) {
        const t = (i * 10 + s.gridOffset) / 200;
        const gy = gLine + t * t * (H - gLine) * 4;
        if (gy > H || gy < gLine) continue;
        const alpha = Math.max(0.02, 0.12 * (1 - (gy - gLine) / (H - gLine)));
        ctx.strokeStyle = `rgba(0,240,255,${alpha})`;
        ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(0, gy); ctx.lineTo(W, gy); ctx.stroke();
      }

      // Perspective vertical lines (vanishing point)
      const vx = W / 2;
      const vy = gLine - 30;
      ctx.strokeStyle = 'rgba(0,240,255,0.06)';
      ctx.lineWidth = 1;
      for (let i = -5; i <= 5; i++) {
        const bx = vx + i * 120;
        ctx.beginPath(); ctx.moveTo(vx + i * 15, vy); ctx.lineTo(bx, H); ctx.stroke();
      }

      // Lane lines (perspective)
      ctx.strokeStyle = 'rgba(0,240,255,0.18)';
      ctx.lineWidth = 2;
      for (let l = -1; l <= 3; l++) {
        const lx = s.laneX[0] + (l) * s.laneW - s.laneW / 2;
        ctx.beginPath();
        ctx.moveTo(vx + (lx - vx) * 0.1, vy + 10);
        ctx.lineTo(lx, H);
        ctx.stroke();
      }

      // Ground glow line
      ctx.strokeStyle = 'rgba(0,240,255,0.35)';
      ctx.lineWidth = 2;
      ctx.shadowColor = '#00f0ff'; ctx.shadowBlur = 8;
      ctx.beginPath(); ctx.moveTo(W * 0.05, gLine); ctx.lineTo(W * 0.95, gLine); ctx.stroke();
      ctx.shadowBlur = 0;

      // ── DRAW COINS ──
      for (const c of s.coinList) {
        if (c.collected) continue;
        ctx.save();
        ctx.translate(c.x, c.y);
        const sc = Math.cos(c.angle);
        ctx.scale(sc || 0.01, 1);
        ctx.shadowColor = c.magnet ? '#3b82f6' : '#fbbf24';
        ctx.shadowBlur = c.magnet ? 15 : 8;
        // Outer ring
        ctx.strokeStyle = '#fbbf24'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(0, 0, 10, 0, Math.PI * 2); ctx.stroke();
        // Inner fill
        ctx.fillStyle = '#fbbf24';
        ctx.beginPath(); ctx.arc(0, 0, 7, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#f59e0b';
        ctx.font = 'bold 9px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText('★', 0, 0);
        ctx.shadowBlur = 0;
        ctx.restore();
      }

      // ── DRAW POWERUPS ──
      for (const p of s.powerups) {
        if (p.collected) continue;
        const bob = Math.sin(p.bobPhase) * 6;
        ctx.save();
        ctx.translate(p.x, p.y + bob);
        ctx.rotate(p.angle);
        const colors: Record<string, string> = { magnet: '#3b82f6', shield: '#22d3ee', double: '#fbbf24', star: '#f472b6' };
        const icons: Record<string, string> = { magnet: '🧲', shield: '🛡️', double: '×2', star: '⭐' };
        const col = colors[p.type] || '#fff';
        ctx.shadowColor = col; ctx.shadowBlur = 20;
        ctx.fillStyle = col + '30'; ctx.strokeStyle = col; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(0, 0, 16, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
        ctx.shadowBlur = 0;
        ctx.fillStyle = '#fff'; ctx.font = p.type === 'double' ? 'bold 12px Orbitron,sans-serif' : '16px sans-serif';
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText(icons[p.type] || '?', 0, 0);
        ctx.restore();
      }

      // ── DRAW OBSTACLES (3D-ish) ──
      for (const o of s.obstacles) {
        const ox = o.x - o.w / 2, oy = o.y - o.h / 2;
        ctx.save();

        if (o.type === 'train') {
          // 3D train body
          const depth = 12;
          ctx.fillStyle = '#1e1b4b'; ctx.fillRect(ox + depth, oy - depth, o.w, o.h); // shadow side
          ctx.fillStyle = '#312e81'; ctx.fillRect(ox, oy, o.w, o.h); // front
          ctx.fillStyle = '#3730a3'; ctx.fillRect(ox, oy, o.w, 18); // roof
          // Windows
          ctx.fillStyle = '#818cf8';
          for (let i = 0; i < 3; i++) ctx.fillRect(ox + 8 + i * 18, oy + 22, 12, 10);
          // Stripe
          ctx.fillStyle = '#fbbf24'; ctx.fillRect(ox, oy + o.h * 0.7, o.w, 4);
          // Glow
          ctx.shadowColor = '#4f46e5'; ctx.shadowBlur = 15;
          ctx.strokeStyle = '#4f46e5'; ctx.lineWidth = 1;
          ctx.strokeRect(ox, oy, o.w, o.h);
        } else if (o.type === 'tall') {
          // Construction barrier
          const depth = 8;
          ctx.fillStyle = '#7c2d12'; ctx.fillRect(ox + depth, oy - depth, o.w, o.h);
          ctx.fillStyle = '#ea580c'; ctx.fillRect(ox, oy, o.w, o.h);
          // Hazard stripes
          ctx.fillStyle = '#000';
          for (let i = 0; i < o.h; i += 14) {
            ctx.fillRect(ox + (i % 28 < 14 ? 2 : 12), oy + i, 10, 7);
          }
          ctx.fillStyle = '#fbbf24';
          ctx.fillRect(ox, oy, o.w, 5); ctx.fillRect(ox, oy + o.h - 5, o.w, 5);
          ctx.shadowColor = '#f97316'; ctx.shadowBlur = 12;
          ctx.strokeStyle = '#f97316'; ctx.lineWidth = 1;
          ctx.strokeRect(ox, oy, o.w, o.h);
        } else if (o.type === 'spike') {
          // Spike trap
          ctx.fillStyle = '#831843';
          ctx.beginPath();
          ctx.moveTo(o.x, oy); ctx.lineTo(ox, oy + o.h); ctx.lineTo(ox + o.w, oy + o.h); ctx.closePath();
          ctx.fill();
          ctx.fillStyle = '#ec4899';
          ctx.beginPath();
          const mid = o.w / 2;
          ctx.moveTo(o.x, oy + 4); ctx.lineTo(ox + 4, oy + o.h - 2); ctx.lineTo(ox + mid, oy + o.h * 0.5);
          ctx.moveTo(o.x, oy + 4); ctx.lineTo(ox + o.w - 4, oy + o.h - 2); ctx.lineTo(ox + mid, oy + o.h * 0.5);
          ctx.fill();
          ctx.shadowColor = '#ec4899'; ctx.shadowBlur = 15;
          ctx.strokeStyle = '#ec4899'; ctx.lineWidth = 1;
          ctx.stroke();
        } else {
          // Low barrier — 3D block
          const depth = 6;
          ctx.fillStyle = '#7f1d1d'; ctx.fillRect(ox + depth, oy - depth, o.w, o.h);
          ctx.fillStyle = '#dc2626'; ctx.fillRect(ox, oy, o.w, o.h);
          ctx.fillStyle = '#fca5a5'; ctx.fillRect(ox + 3, oy + 3, o.w - 6, 5);
          ctx.fillStyle = '#b91c1c'; ctx.fillRect(ox + 3, oy + o.h - 7, o.w - 6, 4);
          ctx.shadowColor = '#ef4444'; ctx.shadowBlur = 10;
          ctx.strokeStyle = '#ef4444'; ctx.lineWidth = 1;
          ctx.strokeRect(ox, oy, o.w, o.h);
        }
        ctx.shadowBlur = 0;
        ctx.restore();
      }

      // ── DRAW PLAYER ──
      ctx.save();
      const pW = 28;
      let pH = 52;
      let drawY = s.py;
      if (s.sliding) { pH = 20; drawY = s.groundY + 6; }
      ctx.translate(s.px, drawY);
      ctx.rotate(s.tilt);
      ctx.scale(s.squash, s.stretch);

      // Shadow on ground
      if (s.jumping) {
        const shadowAlpha = Math.max(0, 0.3 * (1 - (s.groundY - s.py) / 120));
        ctx.fillStyle = `rgba(0,0,0,${shadowAlpha})`;
        ctx.beginPath(); ctx.ellipse(0, s.groundY - drawY + 10, 18 * (1 - (s.groundY - s.py) / 300), 5, 0, 0, Math.PI * 2); ctx.fill();
      }

      // Player glow aura
      const auraColor = s.invincible > 0 ? '#f472b6' : s.shieldHits > 0 ? '#22d3ee' : '#00f0ff';
      const auraAlpha = s.invincible > 0 ? (0.3 + Math.sin(s.frame * 0.3) * 0.2) : 0.15;
      const auraGrad = ctx.createRadialGradient(0, -pH / 2 + 10, 5, 0, -pH / 2 + 10, 40);
      auraGrad.addColorStop(0, auraColor + Math.round(auraAlpha * 255).toString(16).padStart(2, '0'));
      auraGrad.addColorStop(1, auraColor + '00');
      ctx.fillStyle = auraGrad;
      ctx.beginPath(); ctx.arc(0, -pH / 2 + 10, 40, 0, Math.PI * 2); ctx.fill();

      ctx.shadowColor = auraColor;
      ctx.shadowBlur = s.invincible > 0 ? 25 : 15;

      if (!s.sliding) {
        // Legs
        const legSwing = Math.sin(s.runPhase) * (s.jumping ? 0.3 : 10);
        ctx.fillStyle = '#075985';
        ctx.fillRect(-pW / 2 + 3, pH / 2 - 14 + legSwing * 0.5, 9, 14);
        ctx.fillRect(pW / 2 - 12, pH / 2 - 14 - legSwing * 0.5, 9, 14);
        // Shoes
        ctx.fillStyle = '#0369a1';
        ctx.fillRect(-pW / 2 + 2, pH / 2 - 2 + legSwing * 0.5, 11, 4);
        ctx.fillRect(pW / 2 - 13, pH / 2 - 2 - legSwing * 0.5, 11, 4);

        // Body (torso)
        const bodyGrad = ctx.createLinearGradient(0, -pH / 2 + 8, 0, pH / 2 - 12);
        bodyGrad.addColorStop(0, '#0ea5e9');
        bodyGrad.addColorStop(1, '#0284c7');
        ctx.fillStyle = bodyGrad;
        ctx.beginPath();
        ctx.roundRect(-pW / 2, -pH / 2 + 8, pW, pH - 22, 4);
        ctx.fill();

        // Belt
        ctx.fillStyle = '#164e63';
        ctx.fillRect(-pW / 2, pH / 2 - 16, pW, 4);
        ctx.fillStyle = '#fbbf24';
        ctx.fillRect(-3, pH / 2 - 17, 6, 6);

        // Arms
        const armSwing = Math.sin(s.runPhase + Math.PI) * (s.jumping ? 4 : 8);
        ctx.fillStyle = '#0ea5e9';
        ctx.save(); ctx.translate(-pW / 2 - 2, -pH / 2 + 18);
        ctx.rotate(armSwing * 0.06);
        ctx.fillRect(-3, 0, 6, 18); ctx.restore();
        ctx.save(); ctx.translate(pW / 2 + 2, -pH / 2 + 18);
        ctx.rotate(-armSwing * 0.06);
        ctx.fillRect(-3, 0, 6, 18); ctx.restore();

        // Head
        ctx.fillStyle = '#38bdf8';
        ctx.beginPath(); ctx.arc(0, -pH / 2, 12, 0, Math.PI * 2); ctx.fill();

        // Visor
        ctx.fillStyle = '#00f0ff';
        ctx.shadowColor = '#00f0ff'; ctx.shadowBlur = 8;
        ctx.beginPath();
        ctx.roundRect(-9, -pH / 2 - 4, 18, 6, 3);
        ctx.fill();
        ctx.shadowBlur = 0;

        // Hair/helmet top detail
        ctx.fillStyle = '#0c4a6e';
        ctx.beginPath(); ctx.arc(0, -pH / 2 - 5, 8, Math.PI, 0); ctx.fill();
      } else {
        // Sliding pose — flat rectangle with details
        ctx.fillStyle = '#0ea5e9';
        ctx.beginPath(); ctx.roundRect(-pW / 2 - 4, -pH / 2, pW + 8, pH, 6); ctx.fill();
        ctx.fillStyle = '#00f0ff'; ctx.shadowColor = '#00f0ff'; ctx.shadowBlur = 6;
        ctx.fillRect(-pW / 2 - 2, -pH / 2 + 2, pW + 4, 3); ctx.shadowBlur = 0;
        ctx.fillStyle = '#38bdf8';
        ctx.beginPath(); ctx.arc(pW / 2 + 2, 0, 8, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#00f0ff';
        ctx.beginPath(); ctx.roundRect(pW / 2 - 4, -3, 12, 4, 2); ctx.fill();
      }

      // Shield bubble
      if (s.shieldHits > 0) {
        ctx.strokeStyle = `rgba(34,211,238,${0.4 + Math.sin(s.frame * 0.1) * 0.2})`;
        ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(0, -10, 30, 0, Math.PI * 2); ctx.stroke();
      }

      ctx.shadowBlur = 0;
      ctx.restore();

      // ── PARTICLES ──
      for (const p of s.particles) {
        const alpha = Math.max(0, p.life / p.maxLife);
        if (p.glow) { ctx.shadowColor = p.color; ctx.shadowBlur = 8; }
        ctx.globalAlpha = alpha;
        ctx.fillStyle = p.color;
        ctx.beginPath(); ctx.arc(p.x, p.y, p.size * alpha, 0, Math.PI * 2); ctx.fill();
        ctx.shadowBlur = 0;
      }
      ctx.globalAlpha = 1;

      // ── FLOATING TEXTS ──
      for (const ft of s.floatingTexts) {
        const alpha = Math.max(0, ft.life / 60);
        ctx.globalAlpha = alpha;
        ctx.fillStyle = ft.color;
        ctx.font = 'bold 14px Orbitron, monospace';
        ctx.textAlign = 'center';
        ctx.shadowColor = ft.color; ctx.shadowBlur = 6;
        ctx.fillText(ft.text, ft.x, ft.y);
        ctx.shadowBlur = 0;
      }
      ctx.globalAlpha = 1;

      // ── SPEED LINES ──
      if (s.speed > 10) {
        const intensity = (s.speed - 10) / 12;
        ctx.strokeStyle = `rgba(0,240,255,${intensity * 0.15})`;
        ctx.lineWidth = 1.5;
        for (let i = 0; i < 8; i++) {
          const sx = ((s.frame * 97 + i * 173) % (W - 100)) + 50;
          const sy = ((s.frame * 53 + i * 211) % (H * 0.55));
          const len = 25 + s.speed * 3;
          ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(sx + (Math.random() - 0.5) * 8, sy + len); ctx.stroke();
        }
      }

      // ── HUD ──
      // Score
      ctx.fillStyle = '#fff'; ctx.font = 'bold 22px Orbitron, monospace'; ctx.textAlign = 'left';
      ctx.shadowColor = '#00f0ff'; ctx.shadowBlur = 6;
      ctx.fillText(`${Math.floor(s.score).toLocaleString()}`, 24, 38);
      ctx.shadowBlur = 0;
      ctx.fillStyle = '#64748b'; ctx.font = '10px Orbitron, monospace';
      ctx.fillText('SCORE', 24, 52);

      // Distance
      ctx.fillStyle = '#94a3b8'; ctx.font = '14px Orbitron, monospace';
      ctx.fillText(`${Math.floor(s.distance)}m`, 24, 74);

      // Coins (right side)
      ctx.textAlign = 'right';
      ctx.fillStyle = '#fbbf24'; ctx.font = 'bold 18px Orbitron, monospace';
      ctx.shadowColor = '#fbbf24'; ctx.shadowBlur = 4;
      ctx.fillText(`★ ${s.coinCount}`, W - 24, 38);
      ctx.shadowBlur = 0;

      // Combo / Multiplier
      if (s.combo > 0) {
        ctx.textAlign = 'center';
        ctx.fillStyle = '#f472b6'; ctx.font = `bold ${16 + Math.sin(s.frame * 0.15) * 2}px Orbitron, monospace`;
        ctx.shadowColor = '#f472b6'; ctx.shadowBlur = 8;
        ctx.fillText(`${s.multiplier}× COMBO`, W / 2, 36);
        ctx.shadowBlur = 0;
        ctx.fillStyle = 'rgba(244,114,182,0.3)';
        ctx.fillRect(W / 2 - 60, 42, 120 * (s.comboTimer / 90), 3);
      }

      // Active powerup indicators
      const indicators: { label: string; color: string; timer: number; max: number }[] = [];
      if (s.magnetTimer > 0) indicators.push({ label: 'MAGNET', color: '#3b82f6', timer: s.magnetTimer, max: 300 });
      if (s.doubleTimer > 0) indicators.push({ label: '2× COINS', color: '#fbbf24', timer: s.doubleTimer, max: 300 });
      if (s.invincible > 0) indicators.push({ label: 'STAR', color: '#f472b6', timer: s.invincible, max: 180 });
      if (s.shieldHits > 0) indicators.push({ label: 'SHIELD', color: '#22d3ee', timer: 1, max: 1 });
      ctx.textAlign = 'right';
      indicators.forEach((ind, i) => {
        const iy = 60 + i * 22;
        ctx.fillStyle = ind.color; ctx.font = 'bold 10px Orbitron, monospace';
        ctx.fillText(ind.label, W - 24, iy);
        ctx.fillStyle = ind.color + '40';
        ctx.fillRect(W - 100, iy + 3, 76, 4);
        ctx.fillStyle = ind.color;
        ctx.fillRect(W - 100, iy + 3, 76 * (ind.timer / ind.max), 4);
      });

      // Vignette
      const vig = ctx.createRadialGradient(W / 2, H / 2, W * 0.28, W / 2, H / 2, W * 0.72);
      vig.addColorStop(0, 'rgba(0,0,0,0)'); vig.addColorStop(1, 'rgba(0,0,0,0.55)');
      ctx.fillStyle = vig; ctx.fillRect(0, 0, W, H);

      // Screen flash
      if (s.flashAlpha > 0.01) {
        ctx.fillStyle = s.flashColor + Math.round(Math.min(1, s.flashAlpha) * 255).toString(16).padStart(2, '0');
        ctx.fillRect(0, 0, W, H);
      }

      // ── GAME OVER SCREEN ──
      if (!s.running) {
        ctx.fillStyle = 'rgba(0,0,0,0.65)'; ctx.fillRect(0, 0, W, H);

        ctx.textAlign = 'center';
        ctx.fillStyle = '#ef4444'; ctx.font = 'bold 48px Orbitron, monospace';
        ctx.shadowColor = '#ef4444'; ctx.shadowBlur = 30;
        ctx.fillText('GAME OVER', W / 2, H / 2 - 60);
        ctx.shadowBlur = 0;

        ctx.fillStyle = '#e2e8f0'; ctx.font = '18px Orbitron, monospace';
        ctx.fillText(`SCORE: ${Math.floor(s.score).toLocaleString()}`, W / 2, H / 2 - 10);

        ctx.fillStyle = '#fbbf24'; ctx.font = '14px Orbitron, monospace';
        ctx.fillText(`★ ${s.coinCount} COINS  •  ${Math.floor(s.distance)}m  •  BEST: ${Math.max(highScore, Math.floor(s.score)).toLocaleString()}`, W / 2, H / 2 + 20);

        ctx.fillStyle = '#00f0ff'; ctx.font = '16px Orbitron, monospace';
        ctx.shadowColor = '#00f0ff'; ctx.shadowBlur = 10;
        const pulse = 0.7 + Math.sin(s.frame * 0.05) * 0.3;
        ctx.globalAlpha = pulse;
        ctx.fillText('PRESS ENTER OR TAP TO RESTART', W / 2, H / 2 + 65);
        ctx.globalAlpha = 1; ctx.shadowBlur = 0;
      }

      ctx.restore(); // undo shake translate

      // Touch controls hint (bottom)
      if (s.running && s.frame < 180) {
        const hintAlpha = Math.max(0, 1 - s.frame / 180);
        ctx.globalAlpha = hintAlpha;
        ctx.fillStyle = '#475569'; ctx.font = '11px Orbitron, monospace'; ctx.textAlign = 'center';
        ctx.fillText('← → LANES  |  ↑ JUMP  |  ↓ SLIDE  |  SWIPE ON MOBILE', W / 2, H - 16);
        ctx.globalAlpha = 1;
      }

      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);

    const handleRestart = (e: KeyboardEvent) => {
      if (e.key === 'Enter' && gameRef.current && !gameRef.current.running) initGame();
    };
    window.addEventListener('keydown', handleRestart);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('keydown', handleRestart);
    };
  }, [started, initGame, scenery, highScore, coinCount]);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h3 className="font-orbitron text-lg glow-text-cyan" style={{ color: '#00f0ff' }}>▶ PLAYABLE PROTOTYPE</h3>
          <p className="text-xs text-slate-500 mt-1">Generated from video analysis • {result.gameType} • {result.environment}</p>
        </div>
        {!started && <button onClick={initGame} className="neon-btn">▶ LAUNCH GAME</button>}
        {started && (
          <div className="flex items-center gap-5 font-jetbrains text-sm flex-wrap">
            <div className="text-slate-400">SCORE <span style={{ color: '#00f0ff' }} className="font-bold">{score.toLocaleString()}</span></div>
            <div className="text-slate-400">DIST <span style={{ color: '#4ade80' }} className="font-bold">{distance}m</span></div>
            {combo > 0 && <div style={{ color: '#f472b6' }} className="font-bold animate-pulse">{combo}× COMBO</div>}
            {gameOver && <button onClick={initGame} className="neon-btn text-xs py-1 px-4">RESTART</button>}
          </div>
        )}
      </div>

      <div className="game-container relative" style={{ maxWidth: 900 }}>
        <canvas ref={canvasRef} width={W} height={H} className="w-full block" style={{ touchAction: 'none' }} />
        {!started && (
          <div className="absolute inset-0 flex flex-col items-center justify-center" style={{ background: 'rgba(0,0,0,0.88)' }}>
            <div className="font-orbitron text-3xl glow-text-cyan mb-2" style={{ color: '#00f0ff' }}>
              {result.gameType.toUpperCase()}
            </div>
            <div className="text-slate-400 text-sm mb-2">AI-Reconstructed from video analysis</div>
            {highScore > 0 && <div className="text-xs mb-4" style={{ color: '#fbbf24' }}>HIGH SCORE: {highScore.toLocaleString()}</div>}
            <button onClick={initGame} className="neon-btn text-lg px-10 py-4 mb-6">▶ PLAY GAME</button>
            <div className="grid grid-cols-2 gap-x-8 gap-y-2 text-xs text-slate-600 text-center">
              <div>← → <span className="text-slate-400">Switch Lanes</span></div>
              <div>↑ / Space <span className="text-slate-400">Jump</span></div>
              <div>↓ <span className="text-slate-400">Slide</span></div>
              <div>Swipe <span className="text-slate-400">Mobile Controls</span></div>
            </div>
          </div>
        )}
      </div>

      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {[
          { label: 'Movement', value: '3-Lane + Jump + Slide', icon: '🏃' },
          { label: 'Camera', value: result.camera, icon: '📷' },
          { label: 'Difficulty', value: 'Progressive Waves', icon: '📈' },
          { label: 'Obstacles', value: '4 Types + Patterns', icon: '🚧' },
          { label: 'Power-ups', value: 'Magnet • Shield • 2× • Star', icon: '⚡' },
        ].map((item) => (
          <div key={item.label} className="card p-3">
            <div className="text-lg mb-1">{item.icon}</div>
            <div className="font-orbitron text-[10px] tracking-wider" style={{ color: '#00f0ff' }}>{item.label}</div>
            <div className="text-xs text-slate-400 mt-1">{item.value}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
