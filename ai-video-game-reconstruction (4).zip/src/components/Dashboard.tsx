import { useState, useRef, useEffect, useMemo } from 'react';
import {
  Gamepad2, Activity, Eye, Palette, Code, Download,
  ChevronRight, Cpu, Layers, Zap, BarChart3, Sparkles,
  Clapperboard, Target, Monitor
} from 'lucide-react';
import type { AnalysisResult } from '../types';
import GamePreview from './GamePreview';

interface Props {
  result: AnalysisResult;
  onReset: () => void;
}

const TABS = [
  { id: 'overview', label: 'Overview', icon: Cpu },
  { id: 'mechanics', label: 'Mechanics', icon: Gamepad2 },
  { id: 'motion', label: 'Motion', icon: Activity },
  { id: 'objects', label: 'Objects', icon: Eye },
  { id: 'environment', label: 'Environment', icon: Palette },
  { id: 'animations', label: 'Animations', icon: Clapperboard },
  { id: 'code', label: 'Code', icon: Code },
  { id: 'game', label: 'Play Game', icon: Gamepad2 },
  { id: 'export', label: 'Export', icon: Download },
];

export default function Dashboard({ result, onReset }: Props) {
  const [activeTab, setActiveTab] = useState('overview');
  const motionCanvasRef = useRef<HTMLCanvasElement>(null);

  // Pre-compute random data for environment preview so it doesn't flicker
  const envPreview = useMemo(() => ({
    stars: Array.from({ length: 30 }, (_, i) => ({
      left: ((i * 53 + 17) % 100),
      top: ((i * 37 + 11) % 40),
      size: 1 + ((i * 13) % 20) * 0.1,
    })),
    buildings: Array.from({ length: 25 }, (_, i) => ({
      width: 15 + ((i * 23 + 7) % 30),
      height: 30 + ((i * 37 + 13) % 80),
      bg: `hsl(${220 + (i * 17) % 30}, 40%, ${6 + (i * 11) % 8}%)`,
      windows: Array.from({ length: ((i * 7) % 5) + 1 }, (_, j) => ((i * 13 + j * 7) % 10) > 4),
    })),
  }), []);

  // Pre-compute animation bar heights
  const animBars = useMemo(() =>
    result.animations.map((_, ai) =>
      Array.from({ length: 20 }, (_, i) => ({
        height: 40 + Math.sin(i * 0.5 + ai) * 30 + ((i * 13 + ai * 7) % 20),
        opacity: 0.2 + Math.sin(i * 0.3 + ai) * 0.2,
      }))
    ), [result.animations]);

  // Motion canvas animation
  useEffect(() => {
    if (activeTab !== 'motion' || !motionCanvasRef.current) return;
    const canvas = motionCanvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const CW = canvas.width;
    const CH = canvas.height;
    let frame = 0;
    let animId: number;

    const draw = () => {
      ctx.fillStyle = 'rgba(10,10,20,0.15)';
      ctx.fillRect(0, 0, CW, CH);

      ctx.strokeStyle = 'rgba(0,240,255,0.05)'; ctx.lineWidth = 1;
      for (let x = 0; x < CW; x += 40) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, CH); ctx.stroke(); }
      for (let y = 0; y < CH; y += 40) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(CW, y); ctx.stroke(); }

      const data = result.motionData;
      const startIdx = Math.max(0, frame - 60);
      const endIdx = Math.min(data.length - 1, frame);

      for (let i = startIdx; i < endIdx; i++) {
        const d = data[i]; const next = data[i + 1];
        if (!next) continue;
        const alpha = (i - startIdx) / Math.max(1, endIdx - startIdx);
        ctx.strokeStyle = `rgba(0,240,255,${alpha * 0.6})`; ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(d.x * (CW / 800), d.y * (CH / 500));
        ctx.lineTo(next.x * (CW / 800), next.y * (CH / 500));
        ctx.stroke();
      }

      const cur = data[frame % data.length];
      if (cur) {
        const cx = cur.x * (CW / 800); const cy = cur.y * (CH / 500);
        const gradient = ctx.createRadialGradient(cx, cy, 0, cx, cy, 30);
        gradient.addColorStop(0, 'rgba(0,240,255,0.4)'); gradient.addColorStop(1, 'rgba(0,240,255,0)');
        ctx.fillStyle = gradient; ctx.beginPath(); ctx.arc(cx, cy, 30, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#00f0ff'; ctx.beginPath(); ctx.arc(cx, cy, 5, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = 'rgba(139,92,246,0.8)'; ctx.fillRect(cx + 15, cy - 15, cur.velocity * 3, 4);
        ctx.fillStyle = '#94a3b8'; ctx.font = '10px monospace';
        ctx.fillText(`v:${cur.velocity.toFixed(1)} d:${cur.direction}`, cx + 15, cy - 20);

        ctx.strokeStyle = 'rgba(0,240,255,0.6)'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(cx, cy - 20, 6, 0, Math.PI * 2); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(cx, cy - 14); ctx.lineTo(cx, cy + 10); ctx.stroke();
        const arm = Math.sin(frame * 0.2) * 10;
        ctx.beginPath(); ctx.moveTo(cx - 12, cy - 5 + arm); ctx.lineTo(cx, cy - 8); ctx.lineTo(cx + 12, cy - 5 - arm); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(cx - 8, cy + 20 - arm); ctx.lineTo(cx, cy + 10); ctx.lineTo(cx + 8, cy + 20 + arm); ctx.stroke();
      }

      ctx.fillStyle = 'rgba(10,10,20,0.8)'; ctx.fillRect(0, CH - 60, CW, 60);
      ctx.strokeStyle = 'rgba(0,240,255,0.1)'; ctx.beginPath(); ctx.moveTo(0, CH - 30); ctx.lineTo(CW, CH - 30); ctx.stroke();
      ctx.strokeStyle = '#8b5cf6'; ctx.lineWidth = 1.5; ctx.beginPath();
      for (let i = 0; i < data.length; i++) {
        const x = (i / data.length) * CW; const y = CH - 10 - data[i].velocity * 4;
        if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      }
      ctx.stroke();
      const playX = ((frame % data.length) / data.length) * CW;
      ctx.strokeStyle = '#ef4444'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(playX, CH - 60); ctx.lineTo(playX, CH); ctx.stroke();
      ctx.fillStyle = '#94a3b8'; ctx.font = '9px monospace'; ctx.fillText('VELOCITY GRAPH', 10, CH - 48);

      frame++;
      animId = requestAnimationFrame(draw);
    };

    ctx.fillStyle = '#0a0a14'; ctx.fillRect(0, 0, CW, CH);
    draw();
    return () => cancelAnimationFrame(animId);
  }, [activeTab, result.motionData]);

  const renderOverview = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Game Type', value: result.gameType, sub: `${(result.gameTypeConfidence * 100).toFixed(0)}% confidence`, color: '#00f0ff', icon: <Gamepad2 className="w-5 h-5" /> },
          { label: 'Camera', value: result.camera, sub: 'Detected system', color: '#a78bfa', icon: <Monitor className="w-5 h-5" /> },
          { label: 'Environment', value: result.environment, sub: result.environmentStyle, color: '#f472b6', icon: <Layers className="w-5 h-5" /> },
          { label: 'FPS / Frames', value: `${result.fps} FPS`, sub: `${result.totalFrames.toLocaleString()} frames`, color: '#4ade80', icon: <Zap className="w-5 h-5" /> },
        ].map(stat => (
          <div key={stat.label} className="card p-5">
            <div style={{ color: stat.color }} className="mb-3">{stat.icon}</div>
            <div className="font-orbitron text-[10px] tracking-widest text-slate-500 mb-1">{stat.label}</div>
            <div className="text-lg font-semibold text-slate-200">{stat.value}</div>
            <div className="text-xs text-slate-500 mt-1">{stat.sub}</div>
          </div>
        ))}
      </div>

      <div className="card p-6">
        <h3 className="font-orbitron text-sm tracking-wider mb-4 flex items-center gap-2" style={{ color: '#00f0ff' }}>
          <BarChart3 className="w-4 h-4" /> GAMEPLAY STRUCTURE GRAPH
        </h3>
        <div className="code-block text-xs overflow-x-auto">
          <pre>{JSON.stringify(result.gameplayGraph, null, 2)}</pre>
        </div>
      </div>

      <div className="card p-6">
        <h3 className="font-orbitron text-sm tracking-wider mb-4 flex items-center gap-2" style={{ color: '#00f0ff' }}>
          <Palette className="w-4 h-4" /> EXTRACTED COLOR PALETTE
        </h3>
        <div className="flex gap-3 flex-wrap">
          {result.colorPalette.map((color, i) => (
            <div key={i} className="text-center">
              <div className="w-14 h-14 rounded-lg border border-slate-700/50 mb-2" style={{ background: color }} />
              <span className="font-jetbrains text-[10px] text-slate-500">{color}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        <div className="card p-5">
          <h4 className="font-orbitron text-xs tracking-wider mb-3 flex items-center gap-2" style={{ color: '#a78bfa' }}>
            <Monitor className="w-3.5 h-3.5" /> UI ELEMENTS
          </h4>
          <div className="space-y-1.5">
            {result.uiElements.map(ui => (
              <div key={ui} className="flex items-center gap-2 text-sm text-slate-400">
                <ChevronRight className="w-3 h-3" style={{ color: '#a78bfa' }} /> {ui}
              </div>
            ))}
          </div>
        </div>
        <div className="card p-5">
          <h4 className="font-orbitron text-xs tracking-wider mb-3 flex items-center gap-2" style={{ color: '#f472b6' }}>
            <Sparkles className="w-3.5 h-3.5" /> VISUAL EFFECTS
          </h4>
          <div className="space-y-1.5">
            {result.effects.map(fx => (
              <div key={fx} className="flex items-center gap-2 text-sm text-slate-400">
                <ChevronRight className="w-3 h-3" style={{ color: '#f472b6' }} /> {fx}
              </div>
            ))}
          </div>
        </div>
        <div className="card p-5">
          <h4 className="font-orbitron text-xs tracking-wider mb-3 flex items-center gap-2" style={{ color: '#4ade80' }}>
            <Clapperboard className="w-3.5 h-3.5" /> ANIMATIONS
          </h4>
          <div className="space-y-1.5">
            {result.animations.map(anim => (
              <div key={anim} className="flex items-center gap-2 text-sm text-slate-400">
                <ChevronRight className="w-3 h-3" style={{ color: '#4ade80' }} /> {anim}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );

  const renderMechanics = () => (
    <div className="space-y-4">
      <div className="card p-5 mb-4">
        <div className="flex items-center gap-2 mb-2">
          <Target className="w-4 h-4" style={{ color: '#00f0ff' }} />
          <h3 className="font-orbitron text-sm tracking-wider" style={{ color: '#00f0ff' }}>DETECTED GAMEPLAY MECHANICS</h3>
        </div>
        <p className="text-xs text-slate-500">Analysis based on {result.totalFrames.toLocaleString()} frames of gameplay video</p>
      </div>
      <div className="grid md:grid-cols-2 gap-3">
        {result.mechanics.map(mech => (
          <div key={mech.name} className="card p-4" style={{
            borderColor: mech.detected ? 'rgba(34,197,94,0.2)' : undefined,
            opacity: mech.detected ? 1 : 0.6,
          }}>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full" style={{ background: mech.detected ? '#4ade80' : '#475569' }} />
                <span className="font-orbitron text-xs tracking-wider text-slate-300">{mech.name}</span>
              </div>
              <span className="font-jetbrains text-xs font-bold" style={{
                color: mech.confidence > 0.8 ? '#4ade80' : mech.confidence > 0.5 ? '#eab308' : '#ef4444',
              }}>
                {(mech.confidence * 100).toFixed(0)}%
              </span>
            </div>
            <div className="h-1.5 rounded-full overflow-hidden mb-2" style={{ background: '#1e293b' }}>
              <div className="h-full rounded-full" style={{
                width: `${mech.confidence * 100}%`,
                background: mech.confidence > 0.8 ? '#22c55e' : mech.confidence > 0.5 ? '#eab308' : '#ef4444',
              }} />
            </div>
            <p className="text-[11px] text-slate-500 leading-relaxed">{mech.description}</p>
          </div>
        ))}
      </div>
    </div>
  );

  const renderMotion = () => (
    <div className="space-y-4">
      <div className="card p-5">
        <div className="flex items-center gap-2 mb-2">
          <Activity className="w-4 h-4" style={{ color: '#00f0ff' }} />
          <h3 className="font-orbitron text-sm tracking-wider" style={{ color: '#00f0ff' }}>MOTION TRACKING & ANALYSIS</h3>
        </div>
        <p className="text-xs text-slate-500 mb-4">Real-time skeleton tracking with velocity vectors and path prediction</p>
        <div className="rounded-lg overflow-hidden border border-slate-800">
          <canvas ref={motionCanvasRef} width={800} height={400} className="w-full block" />
        </div>
      </div>
      <div className="grid grid-cols-3 gap-4">
        <div className="card p-4 text-center">
          <div className="font-orbitron text-xl" style={{ color: '#00f0ff' }}>{result.motionData.length}</div>
          <div className="text-xs text-slate-500 mt-1">Tracked Points</div>
        </div>
        <div className="card p-4 text-center">
          <div className="font-orbitron text-xl" style={{ color: '#a78bfa' }}>
            {(result.motionData.reduce((a, b) => a + b.velocity, 0) / result.motionData.length).toFixed(1)}
          </div>
          <div className="text-xs text-slate-500 mt-1">Avg Velocity</div>
        </div>
        <div className="card p-4 text-center">
          <div className="font-orbitron text-xl" style={{ color: '#f472b6' }}>3</div>
          <div className="text-xs text-slate-500 mt-1">Lane Positions</div>
        </div>
      </div>
    </div>
  );

  const renderObjects = () => (
    <div className="space-y-4">
      <div className="card p-5">
        <div className="flex items-center gap-2 mb-2">
          <Eye className="w-4 h-4" style={{ color: '#00f0ff' }} />
          <h3 className="font-orbitron text-sm tracking-wider" style={{ color: '#00f0ff' }}>DETECTED OBJECTS (YOLO v8)</h3>
        </div>
        <p className="text-xs text-slate-500">TensorFlow neural network object detection results</p>
      </div>
      <div className="grid md:grid-cols-3 gap-3">
        {result.objects.map(obj => (
          <div key={obj.name} className="card p-4">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: obj.color + '20', border: `1px solid ${obj.color}40` }}>
                <div className="w-3 h-3 rounded" style={{ background: obj.color }} />
              </div>
              <div>
                <div className="text-sm font-medium text-slate-300">{obj.name}</div>
                <div className="text-[10px] text-slate-600 font-jetbrains">{obj.category}</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <div className="flex-1 h-1.5 rounded-full overflow-hidden" style={{ background: '#1e293b' }}>
                <div className="h-full rounded-full" style={{ width: `${obj.confidence * 100}%`, background: obj.color }} />
              </div>
              <span className="font-jetbrains text-xs font-bold" style={{ color: obj.color }}>
                {(obj.confidence * 100).toFixed(0)}%
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderEnvironment = () => (
    <div className="space-y-4">
      <div className="grid md:grid-cols-2 gap-4">
        <div className="card p-6">
          <h4 className="font-orbitron text-xs tracking-wider mb-4" style={{ color: '#00f0ff' }}>SCENE ANALYSIS</h4>
          <div className="space-y-4">
            {[
              { label: 'Environment Type', value: result.environment },
              { label: 'Visual Style', value: result.environmentStyle },
              { label: 'Camera System', value: result.camera },
              { label: 'Lighting', value: 'Dynamic Neon + Ambient' },
              { label: 'Depth', value: '3 Parallax Layers' },
              { label: 'Time of Day', value: 'Night / Dusk' },
            ].map(item => (
              <div key={item.label} className="flex justify-between items-center py-2 border-b border-slate-800/50">
                <span className="text-xs text-slate-500">{item.label}</span>
                <span className="text-sm text-slate-300 font-medium">{item.value}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="card p-6">
          <h4 className="font-orbitron text-xs tracking-wider mb-4" style={{ color: '#a78bfa' }}>COLOR ANALYSIS</h4>
          <div className="grid grid-cols-4 gap-3 mb-4">
            {result.colorPalette.map((c, i) => (
              <div key={i}>
                <div className="aspect-square rounded-lg border border-slate-700/50 mb-1" style={{ background: c }} />
                <div className="font-jetbrains text-[9px] text-slate-600 text-center">{c}</div>
              </div>
            ))}
          </div>
          <div className="text-xs text-slate-500">
            Dominant mood: <span style={{ color: '#a78bfa' }}>Dark Cyberpunk</span><br />
            Accent colors: <span style={{ color: '#00f0ff' }}>Neon Cyan</span>, <span style={{ color: '#f472b6' }}>Hot Pink</span>
          </div>
        </div>
      </div>

      <div className="card p-6">
        <h4 className="font-orbitron text-xs tracking-wider mb-4" style={{ color: '#f472b6' }}>GENERATED ENVIRONMENT PREVIEW</h4>
        <div className="h-40 rounded-lg overflow-hidden relative" style={{
          background: 'linear-gradient(180deg, #050510 0%, #0a0a20 30%, #1a1a3a 70%, #0f0f2a 100%)'
        }}>
          {envPreview.stars.map((s, i) => (
            <div key={i} className="absolute rounded-full" style={{
              left: `${s.left}%`, top: `${s.top}%`,
              width: `${s.size}px`, height: `${s.size}px`,
              background: 'rgba(255,255,255,0.4)',
            }} />
          ))}
          <div className="absolute bottom-0 left-0 right-0 flex items-end gap-1 px-2">
            {envPreview.buildings.map((b, i) => (
              <div key={i} className="flex-shrink-0" style={{
                width: `${b.width}px`, height: `${b.height}px`,
                background: b.bg, borderRadius: '2px 2px 0 0',
              }}>
                {b.windows.map((on, j) => (
                  <div key={j} className="mx-auto mt-2" style={{
                    width: '3px', height: '3px',
                    background: on ? 'rgba(0,240,255,0.3)' : 'transparent',
                  }} />
                ))}
              </div>
            ))}
          </div>
          <div className="absolute bottom-0 left-0 right-0 h-px" style={{ background: 'rgba(0,240,255,0.3)' }} />
          <div className="absolute bottom-0 left-0 right-0 h-8" style={{
            background: 'repeating-linear-gradient(90deg, transparent, transparent 30px, rgba(0,240,255,0.05) 30px, rgba(0,240,255,0.05) 31px)'
          }} />
        </div>
      </div>
    </div>
  );

  const renderAnimations = () => (
    <div className="space-y-4">
      <div className="card p-5">
        <h3 className="font-orbitron text-sm tracking-wider mb-4 flex items-center gap-2" style={{ color: '#00f0ff' }}>
          <Clapperboard className="w-4 h-4" /> ANIMATION ANALYSIS
        </h3>
        <div className="grid md:grid-cols-2 gap-4">
          {result.animations.map((anim, ai) => (
            <div key={anim} className="p-4 rounded-lg" style={{ background: 'rgba(30,41,59,0.3)', border: '1px solid rgba(51,65,85,0.3)' }}>
              <div className="flex items-center gap-2 mb-2">
                <div className="w-2 h-2 rounded-full" style={{ background: '#4ade80' }} />
                <span className="text-sm text-slate-300">{anim}</span>
              </div>
              <div className="h-8 rounded flex items-center px-2 gap-0.5" style={{ background: 'rgba(15,23,42,0.5)' }}>
                {animBars[ai]?.map((bar, i) => (
                  <div key={i} className="flex-1 rounded-sm" style={{
                    height: `${bar.height}%`,
                    background: `rgba(0,240,255,${bar.opacity})`,
                  }} />
                ))}
              </div>
              <div className="flex justify-between mt-1 text-[9px] text-slate-600 font-jetbrains">
                <span>0ms</span>
                <span>frame timing</span>
                <span>600ms</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="card p-5">
        <h4 className="font-orbitron text-xs tracking-wider mb-3" style={{ color: '#a78bfa' }}>STATE MACHINE</h4>
        <div className="flex items-center gap-3 overflow-x-auto pb-2">
          {['Idle', 'Running', 'Jumping', 'Falling', 'Sliding', 'Hit', 'GameOver'].map((state, i) => (
            <div key={state} className="flex items-center gap-2 flex-shrink-0">
              <div className="px-3 py-2 rounded text-xs font-jetbrains" style={{
                border: '1px solid rgba(139,92,246,0.3)',
                background: 'rgba(139,92,246,0.05)',
                color: '#c4b5fd',
              }}>
                {state}
              </div>
              {i < 6 && <ChevronRight className="w-4 h-4 text-slate-600" />}
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderCode = () => (
    <div className="space-y-4">
      <div className="card p-5">
        <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <Code className="w-4 h-4" style={{ color: '#00f0ff' }} />
            <h3 className="font-orbitron text-sm tracking-wider" style={{ color: '#00f0ff' }}>GENERATED CODE</h3>
          </div>
          <div className="flex items-center gap-2">
            <span className="font-jetbrains text-xs text-slate-500">{result.generatedCode.split('\n').length} lines</span>
            <button
              onClick={() => navigator.clipboard.writeText(result.generatedCode)}
              className="px-3 py-1 rounded text-xs font-orbitron transition"
              style={{ background: 'rgba(0,240,255,0.1)', border: '1px solid rgba(0,240,255,0.2)', color: '#00f0ff' }}
            >
              COPY
            </button>
          </div>
        </div>
        <div className="code-block max-h-[600px] overflow-y-auto">
          <pre className="text-xs leading-relaxed">
            {result.generatedCode.split('\n').map((line, i) => (
              <div key={i} className="flex">
                <span className="w-8 text-right mr-4 select-none flex-shrink-0" style={{ color: '#334155' }}>{i + 1}</span>
                <span style={{
                  color: line.trim().startsWith('//') ? 'rgba(74,222,128,0.6)' :
                    line.includes('class ') ? '#fbbf24' :
                    line.includes('function') || line.includes('=>') ? '#60a5fa' :
                    line.includes('this.') ? '#a78bfa' :
                    (line.includes("'") || line.includes('"')) ? '#86efac' :
                    '#94a3b8',
                }}>
                  {line || '\u00A0'}
                </span>
              </div>
            ))}
          </pre>
        </div>
      </div>
    </div>
  );

  const renderGame = () => <GamePreview result={result} />;

  const renderExport = () => (
    <div className="space-y-4">
      <div className="card p-5 mb-4">
        <h3 className="font-orbitron text-sm tracking-wider mb-2 flex items-center gap-2" style={{ color: '#00f0ff' }}>
          <Download className="w-4 h-4" /> EXPORT OPTIONS
        </h3>
        <p className="text-xs text-slate-500">Export your AI-reconstructed game in various formats</p>
      </div>
      <div className="grid md:grid-cols-2 gap-4">
        {[
          { title: 'HTML5 Game Package', desc: 'Complete standalone HTML5 game with Canvas2D rendering', format: 'ZIP', icon: '🌐', size: '~2.4 MB' },
          { title: 'Three.js Project', desc: '3D game project with Three.js scene and controls', format: 'ZIP', icon: '🎲', size: '~4.1 MB' },
          { title: 'Gameplay JSON', desc: 'Structured gameplay data: mechanics, objects, timing', format: 'JSON', icon: '📊', size: '~48 KB' },
          { title: 'Generated Source Code', desc: 'All generated JavaScript game systems', format: 'JS', icon: '💻', size: '~156 KB' },
          { title: 'Analysis Report', desc: 'Full analysis report with all detected systems', format: 'PDF', icon: '📄', size: '~1.2 MB' },
          { title: 'AI Prompt Pack', desc: 'Reconstructed prompts for further AI generation', format: 'TXT', icon: '🤖', size: '~12 KB' },
        ].map(item => (
          <div key={item.title} className="card p-5 flex items-start gap-4 group" style={{ cursor: 'pointer' }}>
            <div className="text-3xl">{item.icon}</div>
            <div className="flex-1">
              <div className="text-sm font-medium text-slate-300">{item.title}</div>
              <div className="text-xs text-slate-500 mt-1">{item.desc}</div>
              <div className="flex items-center gap-3 mt-3">
                <span className="px-2 py-0.5 rounded text-[10px] font-jetbrains" style={{ background: 'rgba(30,41,59,0.5)', color: '#64748b' }}>{item.format}</span>
                <span className="text-[10px] text-slate-600">{item.size}</span>
              </div>
            </div>
            <button
              onClick={() => {
                if (item.format === 'JSON') {
                  const blob = new Blob([JSON.stringify(result.gameplayGraph, null, 2)], { type: 'application/json' });
                  const url = URL.createObjectURL(blob); const a = document.createElement('a');
                  a.href = url; a.download = 'gameplay-analysis.json'; a.click(); URL.revokeObjectURL(url);
                } else if (item.format === 'JS') {
                  const blob = new Blob([result.generatedCode], { type: 'text/javascript' });
                  const url = URL.createObjectURL(blob); const a = document.createElement('a');
                  a.href = url; a.download = 'game-engine.js'; a.click(); URL.revokeObjectURL(url);
                }
              }}
              className="neon-btn text-xs py-2 px-4 flex-shrink-0"
            >
              EXPORT
            </button>
          </div>
        ))}
      </div>
    </div>
  );

  const tabContent: Record<string, () => React.JSX.Element> = {
    overview: renderOverview,
    mechanics: renderMechanics,
    motion: renderMotion,
    objects: renderObjects,
    environment: renderEnvironment,
    animations: renderAnimations,
    code: renderCode,
    game: renderGame,
    export: renderExport,
  };

  return (
    <div className="max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-6 flex-wrap gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-green-500/20 bg-green-500/5 text-xs font-orbitron tracking-widest mb-3" style={{ color: '#4ade80' }}>
            <span className="w-2 h-2 rounded-full" style={{ background: '#4ade80' }} />
            ANALYSIS COMPLETE
          </div>
          <h2 className="font-orbitron text-2xl md:text-3xl font-bold">
            <span className="bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
              Reconstruction Dashboard
            </span>
          </h2>
        </div>
        <button onClick={onReset} className="neon-btn text-xs py-2 px-4">← NEW ANALYSIS</button>
      </div>

      <div className="flex gap-1 mb-1 overflow-x-auto pb-2">
        {TABS.map(tab => (
          <button
            key={tab.id}
            className={`tab-btn flex items-center gap-1.5 ${activeTab === tab.id ? 'active' : ''}`}
            onClick={() => setActiveTab(tab.id)}
          >
            <tab.icon className="w-3.5 h-3.5" />
            {tab.label}
          </button>
        ))}
      </div>

      <div className="card p-6">
        {tabContent[activeTab]?.()}
      </div>
    </div>
  );
}
