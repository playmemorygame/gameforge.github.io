import { useState, useRef, useCallback } from 'react';
import { Upload, Film, FolderOpen, Play, X, FileCode2, Check } from 'lucide-react';
import type { VideoFile, ProjectFile } from '../types';

interface Props {
  onAnalyze: (video: VideoFile, project: ProjectFile | null) => void;
}

export default function UploadSection({ onAnalyze }: Props) {
  const [video, setVideo] = useState<VideoFile | null>(null);
  const [project, setProject] = useState<ProjectFile | null>(null);
  const [videoDragOver, setVideoDragOver] = useState(false);
  const [projectDragOver, setProjectDragOver] = useState(false);
  const videoInputRef = useRef<HTMLInputElement>(null);
  const projectInputRef = useRef<HTMLInputElement>(null);

  const handleVideoFile = useCallback((file: File) => {
    const url = URL.createObjectURL(file);
    setVideo({ file, url, name: file.name, size: file.size, type: file.type });
  }, []);

  const handleProjectFile = useCallback((file: File) => {
    setProject({ file, name: file.name, size: file.size, type: file.type });
  }, []);

  const handleDrop = useCallback((e: React.DragEvent, type: 'video' | 'project') => {
    e.preventDefault();
    setVideoDragOver(false);
    setProjectDragOver(false);
    const file = e.dataTransfer.files[0];
    if (!file) return;
    if (type === 'video') handleVideoFile(file);
    else handleProjectFile(file);
  }, [handleVideoFile, handleProjectFile]);

  const formatSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / 1048576).toFixed(1) + ' MB';
  };

  return (
    <div className="max-w-6xl mx-auto">
      <div className="text-center mb-12">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-cyan-500/20 bg-cyan-500/5 text-cyan-400 text-xs font-orbitron tracking-widest mb-6">
          <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
          AI ENGINE READY
        </div>
        <h2 className="font-orbitron text-3xl md:text-5xl font-bold mb-4">
          <span className="bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
            Upload Your Gameplay
          </span>
        </h2>
        <p className="text-slate-400 max-w-2xl mx-auto text-base leading-relaxed">
          Drop a gameplay video and an optional game template. Our AI will deeply analyze every frame,
          detect mechanics, track motion, and reconstruct a playable prototype.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-6 mb-8">
        {/* Video Upload */}
        <div>
          <div className="flex items-center gap-2 mb-3">
            <Film className="w-4 h-4 text-cyan-400" />
            <h3 className="font-orbitron text-sm tracking-wider text-cyan-400">GAMEPLAY VIDEO</h3>
            <span className="text-xs text-red-400 font-medium ml-1">REQUIRED</span>
          </div>

          {!video ? (
            <div
              className={`drop-zone flex flex-col items-center justify-center px-6 py-12 ${videoDragOver ? 'drag-over' : ''}`}
              style={{ minHeight: 288 }}
              onDragOver={(e) => { e.preventDefault(); setVideoDragOver(true); }}
              onDragLeave={() => setVideoDragOver(false)}
              onDrop={(e) => handleDrop(e, 'video')}
              onClick={() => videoInputRef.current?.click()}
            >
              <input
                ref={videoInputRef}
                type="file"
                accept="video/mp4,video/webm,video/quicktime,.mp4,.webm,.mov"
                className="hidden"
                onChange={(e) => e.target.files?.[0] && handleVideoFile(e.target.files[0])}
              />
              <div className="w-16 h-16 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center mb-4">
                <Upload className="w-7 h-7 text-cyan-400" />
              </div>
              <p className="text-slate-300 font-medium mb-1">Drag & drop gameplay video</p>
              <p className="text-slate-500 text-sm mb-4">or click to browse</p>
              <div className="flex gap-2">
                {['MP4', 'MOV', 'WEBM'].map(f => (
                  <span key={f} className="px-2.5 py-1 rounded bg-slate-800/50 border border-slate-700/50 text-slate-500 text-xs font-jetbrains">{f}</span>
                ))}
              </div>
            </div>
          ) : (
            <div className="drop-zone has-file p-4" style={{ minHeight: 288 }}>
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-400" />
                  <span className="text-green-400 text-sm font-medium truncate max-w-[200px]">{video.name}</span>
                </div>
                <button
                  onClick={(e) => { e.stopPropagation(); setVideo(null); }}
                  className="text-slate-500 hover:text-red-400 transition p-1"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="relative rounded-lg overflow-hidden bg-black border border-slate-800" style={{ height: 192 }}>
                <video
                  src={video.url}
                  className="w-full h-full object-contain"
                  controls
                  muted
                />
              </div>
              <div className="flex items-center gap-4 mt-2 text-xs text-slate-500">
                <span>{formatSize(video.size)}</span>
                <span>{video.type}</span>
              </div>
            </div>
          )}
        </div>

        {/* Project Upload */}
        <div>
          <div className="flex items-center gap-2 mb-3">
            <FolderOpen className="w-4 h-4 text-purple-400" />
            <h3 className="font-orbitron text-sm tracking-wider text-purple-400">PROJECT TEMPLATE</h3>
            <span className="text-xs text-slate-600 font-medium ml-1">OPTIONAL</span>
          </div>

          {!project ? (
            <div
              className={`drop-zone flex flex-col items-center justify-center px-6 py-12 ${projectDragOver ? 'drag-over' : ''}`}
              style={{ minHeight: 288 }}
              onDragOver={(e) => { e.preventDefault(); setProjectDragOver(true); }}
              onDragLeave={() => setProjectDragOver(false)}
              onDrop={(e) => handleDrop(e, 'project')}
              onClick={() => projectInputRef.current?.click()}
            >
              <input
                ref={projectInputRef}
                type="file"
                accept=".zip,.html,.json,.js,.ts,.gd,.tscn,.unity"
                className="hidden"
                onChange={(e) => e.target.files?.[0] && handleProjectFile(e.target.files[0])}
              />
              <div className="w-16 h-16 rounded-2xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center mb-4">
                <FileCode2 className="w-7 h-7 text-purple-400" />
              </div>
              <p className="text-slate-300 font-medium mb-1">Upload game template</p>
              <p className="text-slate-500 text-sm mb-4">HTML5, Three.js, Unity, Godot projects</p>
              <div className="flex flex-wrap gap-2 justify-center">
                {['ZIP', 'HTML', 'JS', 'JSON', 'Unity', 'Godot'].map(f => (
                  <span key={f} className="px-2.5 py-1 rounded bg-slate-800/50 border border-slate-700/50 text-slate-500 text-xs font-jetbrains">{f}</span>
                ))}
              </div>
            </div>
          ) : (
            <div className="drop-zone has-file p-6 flex flex-col items-center justify-center" style={{ minHeight: 288 }}>
              <button
                onClick={(e) => { e.stopPropagation(); setProject(null); }}
                className="absolute top-4 right-4 text-slate-500 hover:text-red-400 transition p-1"
              >
                <X className="w-4 h-4" />
              </button>
              <div className="w-16 h-16 rounded-2xl bg-green-500/10 border border-green-500/30 flex items-center justify-center mb-4">
                <Check className="w-8 h-8 text-green-400" />
              </div>
              <p className="text-green-400 font-medium mb-1">{project.name}</p>
              <p className="text-slate-500 text-sm">{formatSize(project.size)}</p>
              <div className="mt-4 px-3 py-1.5 rounded bg-green-500/10 border border-green-500/20 text-green-400 text-xs font-orbitron tracking-wider">
                TEMPLATE LOADED
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Capabilities */}
      <div className="card p-5 mb-8">
        <h4 className="font-orbitron text-xs tracking-wider text-slate-500 mb-4">AI DETECTION CAPABILITIES</h4>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
          {[
            '🏃 Movement', '🦘 Jumping', '🛝 Sliding', '🚗 Driving', '⚔️ Combat', '🧗 Climbing',
            '📷 Camera', '🌆 Environment', '🚧 Obstacles', '💰 Collectibles', '🎯 Scoring', '🎨 UI/HUD',
            '✨ Effects', '🎬 Animations', '🕹️ Controls', '📊 Pacing', '🔄 Game Loop', '🤖 AI Spawning',
          ].map(cap => (
            <div key={cap} className="flex items-center gap-2 px-3 py-2 rounded-lg bg-slate-800/30 border border-slate-700/30 text-sm text-slate-400">
              {cap}
            </div>
          ))}
        </div>
      </div>

      {/* Launch */}
      <div className="text-center">
        <button
          className="neon-btn text-lg px-12 py-4"
          disabled={!video}
          onClick={() => video && onAnalyze(video, project)}
        >
          <Play className="w-5 h-5 mr-3" />
          LAUNCH AI ANALYSIS ENGINE
        </button>
        {!video && (
          <p className="text-slate-600 text-xs mt-3 font-jetbrains">Upload a gameplay video to begin</p>
        )}
      </div>
    </div>
  );
}
