import { useState, useEffect, useRef } from 'react';
import { CheckCircle, Loader, Clock } from 'lucide-react';
import { ANALYSIS_STAGES, generateAnalysisResult } from '../types';
import type { AnalysisStage, VideoFile } from '../types';

interface Props {
  video: VideoFile;
  onComplete: (result: ReturnType<typeof generateAnalysisResult>) => void;
}

export default function AnalysisPipeline({ video, onComplete }: Props) {
  const [stages, setStages] = useState<AnalysisStage[]>(
    ANALYSIS_STAGES.map(s => ({ ...s, progress: 0, status: 'pending' }))
  );
  const [overallProgress, setOverallProgress] = useState(0);
  const [logs, setLogs] = useState<string[]>([]);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [framesProcessed, setFramesProcessed] = useState(0);
  const logRef = useRef<HTMLDivElement>(null);
  const completedRef = useRef(false);
  const onCompleteRef = useRef(onComplete);
  onCompleteRef.current = onComplete;

  // Timer
  useEffect(() => {
    const timer = setInterval(() => setElapsedTime(t => t + 0.1), 100);
    return () => clearInterval(timer);
  }, []);

  // Frame counter
  useEffect(() => {
    const timer = setInterval(() => {
      setFramesProcessed(f => Math.min(3600, f + Math.floor(Math.random() * 30 + 10)));
    }, 100);
    return () => clearInterval(timer);
  }, []);

  // Auto-scroll
  useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight;
  }, [logs]);

  // Main pipeline — runs once
  useEffect(() => {
    if (completedRef.current) return;
    completedRef.current = true;

    const addLog = (msg: string) => {
      const ts = new Date().toISOString().split('T')[1].slice(0, 12);
      setLogs(prev => [...prev.slice(-80), `[${ts}] ${msg}`]);
    };

    const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

    const runStages = async () => {
      for (let i = 0; i < ANALYSIS_STAGES.length; i++) {
        addLog(`▶ Starting: ${ANALYSIS_STAGES[i].name}`);
        addLog(`  ${ANALYSIS_STAGES[i].description}`);

        setStages(prev => prev.map((s, idx) =>
          idx === i ? { ...s, status: 'running', progress: 0 } : s
        ));

        const details = ANALYSIS_STAGES[i].details || [];
        const stepsPerDetail = 100 / (details.length || 4);

        for (let d = 0; d < details.length; d++) {
          addLog(`  → ${details[d]}`);
          const targetProgress = Math.min(100, (d + 1) * stepsPerDetail);
          const increment = 2 + Math.random() * 3;
          let currentProgress = d * stepsPerDetail;

          while (currentProgress < targetProgress) {
            currentProgress = Math.min(targetProgress, currentProgress + increment);
            const cp = currentProgress;
            const si = i;
            setStages(prev => prev.map((s, idx) =>
              idx === si ? { ...s, progress: Math.round(cp) } : s
            ));
            setOverallProgress(Math.round((si * 100 + cp) / ANALYSIS_STAGES.length));
            await sleep(40 + Math.random() * 50);
          }
        }

        addLog(`✓ Complete: ${ANALYSIS_STAGES[i].name}`);
        setStages(prev => prev.map((s, idx) =>
          idx === i ? { ...s, status: 'complete', progress: 100 } : s
        ));
      }

      addLog('');
      addLog('═══════════════════════════════════════');
      addLog('✓ ALL ANALYSIS STAGES COMPLETE');
      addLog('  Generating playable prototype...');
      addLog('  Building gameplay reconstruction...');
      addLog('═══════════════════════════════════════');

      setOverallProgress(100);
      await sleep(1500);
      const result = generateAnalysisResult();
      onCompleteRef.current(result);
    };

    runStages();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const formatTime = (t: number) => {
    const m = Math.floor(t / 60);
    const s = Math.floor(t % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="max-w-6xl mx-auto">
      {/* Header */}
      <div className="text-center mb-8">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-purple-500/20 bg-purple-500/5 text-purple-400 text-xs font-orbitron tracking-widest mb-4">
          <Loader className="w-3 h-3 animate-spin" />
          AI ENGINE PROCESSING
        </div>
        <h2 className="font-orbitron text-2xl md:text-4xl font-bold mb-2">
          <span className="bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
            Analyzing Gameplay
          </span>
        </h2>
        <p className="text-slate-500 text-sm">
          Processing: <span className="text-slate-300">{video.name}</span>
        </p>
      </div>

      {/* Overall progress */}
      <div className="card p-6 mb-6">
        <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500/20 to-purple-500/20 border border-cyan-500/30 flex items-center justify-center">
              <Loader className={`w-5 h-5 text-cyan-400 ${overallProgress < 100 ? 'animate-spin' : ''}`} />
            </div>
            <div>
              <div className="font-orbitron text-sm tracking-wider text-cyan-400">OVERALL PROGRESS</div>
              <div className="text-xs text-slate-500">Deep analysis pipeline</div>
            </div>
          </div>
          <div className="flex items-center gap-6 text-xs font-jetbrains">
            <div className="text-slate-500">
              <Clock className="w-3 h-3 inline mr-1" />
              {formatTime(elapsedTime)}
            </div>
            <div className="text-slate-500">
              Frames: <span className="text-cyan-400">{framesProcessed.toLocaleString()}</span>/3,600
            </div>
            <div className="text-2xl font-orbitron font-bold glow-text-cyan" style={{ color: '#00f0ff' }}>
              {overallProgress}%
            </div>
          </div>
        </div>
        <div className="h-3 rounded-full overflow-hidden" style={{ background: '#1e293b' }}>
          <div
            className="h-full rounded-full transition-all duration-200 progress-stripe"
            style={{
              width: `${overallProgress}%`,
              background: overallProgress >= 100
                ? 'linear-gradient(90deg, #22c55e, #4ade80)'
                : 'linear-gradient(90deg, #00f0ff, #8b5cf6, #f472b6)',
            }}
          />
        </div>
      </div>

      <div className="grid md:grid-cols-5 gap-6">
        {/* Stages list */}
        <div className="md:col-span-2 space-y-2">
          {stages.map((stage) => (
            <div
              key={stage.id}
              className="card p-4"
              style={{
                borderColor: stage.status === 'running' ? 'rgba(0,240,255,0.3)' :
                  stage.status === 'complete' ? 'rgba(34,197,94,0.2)' : undefined,
                background: stage.status === 'running' ? 'rgba(0,240,255,0.03)' :
                  stage.status === 'complete' ? 'rgba(34,197,94,0.03)' : undefined,
              }}
            >
              <div className="flex items-center gap-3">
                <div className="text-xl flex-shrink-0">{stage.icon}</div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-orbitron text-xs tracking-wider text-slate-300">{stage.name}</span>
                    {stage.status === 'complete' && (
                      <CheckCircle className="w-3.5 h-3.5 text-green-400 check-animate flex-shrink-0" />
                    )}
                    {stage.status === 'running' && (
                      <Loader className="w-3.5 h-3.5 text-cyan-400 animate-spin flex-shrink-0" />
                    )}
                  </div>
                  <div className="text-[11px] text-slate-600 mt-0.5 truncate">{stage.description}</div>
                  {(stage.status === 'running' || stage.status === 'complete') && (
                    <div className="mt-2 h-1.5 rounded-full overflow-hidden" style={{ background: '#1e293b' }}>
                      <div
                        className="h-full rounded-full transition-all duration-200"
                        style={{
                          width: `${stage.progress}%`,
                          background: stage.status === 'complete' ? '#22c55e' : 'linear-gradient(90deg, #00f0ff, #8b5cf6)',
                        }}
                      />
                    </div>
                  )}
                </div>
                <span className="font-jetbrains text-xs text-slate-600 flex-shrink-0">
                  {stage.status === 'complete' ? '100%' : stage.status === 'running' ? `${stage.progress}%` : '—'}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Log terminal */}
        <div className="md:col-span-3">
          <div className="card flex flex-col" style={{ height: '100%' }}>
            <div className="flex items-center gap-2 px-4 py-3 border-b border-slate-800/50">
              <div className="flex gap-1.5">
                <div className="w-3 h-3 rounded-full bg-red-500/60" />
                <div className="w-3 h-3 rounded-full bg-yellow-500/60" />
                <div className="w-3 h-3 rounded-full bg-green-500/60" />
              </div>
              <span className="font-jetbrains text-xs text-slate-500 ml-2">gameforge-ai-pipeline.log</span>
            </div>
            <div
              ref={logRef}
              className="flex-1 p-4 overflow-y-auto font-jetbrains text-xs leading-relaxed"
              style={{ maxHeight: 480, minHeight: 480 }}
            >
              <div className="text-slate-600 mb-2">
                {'>'} GameForge AI Engine v3.2.0 initialized<br />
                {'>'} TensorFlow backend: WebGL (GPU accelerated)<br />
                {'>'} MediaPipe Pose model loaded<br />
                {'>'} YOLO v8 detector ready<br />
                {'>'} FFmpeg WASM codec initialized<br />
                {'>'} Video source: {video.name}<br />
                {'>'} Starting deep analysis pipeline...<br />
                <br />
              </div>
              {logs.map((log, i) => (
                <div
                  key={i}
                  style={{
                    color: log.startsWith('✓') ? '#4ade80' :
                      log.startsWith('▶') ? '#00f0ff' :
                      log.startsWith('═') ? '#a78bfa' :
                      log.startsWith('  →') ? '#64748b' :
                      '#94a3b8',
                  }}
                >
                  {log || '\u00A0'}
                </div>
              ))}
              {overallProgress < 100 && (
                <span className="inline-block w-2 h-4 animate-pulse" style={{ background: '#00f0ff' }} />
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
        {[
          { label: 'Objects Detected', value: Math.min(142, Math.floor(framesProcessed * 0.04)), color: '#00f0ff' },
          { label: 'Motion Vectors', value: Math.min(2840, framesProcessed * 0.8 | 0), color: '#a78bfa' },
          { label: 'Patterns Found', value: Math.min(37, Math.floor(overallProgress * 0.37)), color: '#f472b6' },
          { label: 'Code Lines Gen', value: Math.min(1260, Math.floor(overallProgress * 12.6)), color: '#4ade80' },
        ].map(stat => (
          <div key={stat.label} className="card p-4 text-center">
            <div className="font-orbitron text-2xl font-bold" style={{ color: stat.color }}>
              {stat.value.toLocaleString()}
            </div>
            <div className="text-xs text-slate-500 mt-1 font-orbitron tracking-wider">{stat.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
