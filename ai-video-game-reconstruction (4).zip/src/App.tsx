import { useState, useCallback } from 'react';
import UploadSection from './components/UploadSection';
import AnalysisPipeline from './components/AnalysisPipeline';
import Dashboard from './components/Dashboard';
import type { AppStep, VideoFile, ProjectFile, AnalysisResult } from './types';
import { Cpu, Layers, Zap, Braces, Shield, Eye, Globe } from 'lucide-react';

function ParticleField() {
  const [particles] = useState(() =>
    Array.from({ length: 40 }, (_, i) => ({
      id: i,
      left: ((i * 53 + 17) % 100),
      delay: ((i * 37) % 15),
      duration: 8 + ((i * 23) % 12),
      size: 1 + ((i * 13) % 30) * 0.1,
      opacity: 0.1 + ((i * 7) % 30) * 0.01,
    }))
  );

  return (
    <div className="particles">
      {particles.map(p => (
        <div
          key={p.id}
          className="absolute rounded-full"
          style={{
            left: `${p.left}%`,
            bottom: '-10px',
            width: `${p.size}px`,
            height: `${p.size}px`,
            background: `rgba(0, 240, 255, ${p.opacity})`,
            animation: `particle-float ${p.duration}s linear ${p.delay}s infinite`,
          }}
        />
      ))}
    </div>
  );
}

function Header({ step }: { step: AppStep }) {
  return (
    <header className="relative z-10 border-b border-slate-800/50 backdrop-blur-xl" style={{ background: 'rgba(15,23,42,0.3)' }}>
      <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-purple-600 flex items-center justify-center">
              <Zap className="w-5 h-5 text-white" />
            </div>
            <div className="absolute -top-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-slate-900 animate-pulse" style={{ background: '#4ade80' }} />
          </div>
          <div>
            <h1 className="font-orbitron text-lg font-bold tracking-wider">
              <span style={{ color: '#00f0ff' }}>GAME</span>
              <span className="text-white">FORGE</span>
              <span style={{ color: '#a78bfa' }} className="ml-1.5">AI</span>
            </h1>
            <p className="text-[10px] text-slate-500 tracking-[0.2em] font-orbitron">
              VIDEO TO GAME RECONSTRUCTION
            </p>
          </div>
        </div>

        <div className="hidden md:flex items-center gap-6">
          <div className="flex items-center gap-2">
            {[
              { label: 'UPLOAD', s: 'upload' as const },
              { label: 'ANALYZE', s: 'analyzing' as const },
              { label: 'RESULTS', s: 'results' as const },
            ].map((item, i) => {
              const isCurrent = step === item.s;
              const isPast = (step === 'results') || (step === 'analyzing' && item.s === 'upload');
              const isActive = isCurrent || isPast;

              return (
                <div key={item.s} className="flex items-center gap-2">
                  <div
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[10px] font-orbitron tracking-wider transition-all"
                    style={{
                      background: isCurrent ? 'rgba(0,240,255,0.1)' : isPast ? 'rgba(34,197,94,0.1)' : 'rgba(30,41,59,0.3)',
                      border: `1px solid ${isCurrent ? 'rgba(0,240,255,0.3)' : isPast ? 'rgba(34,197,94,0.2)' : 'rgba(51,65,85,0.3)'}`,
                      color: isCurrent ? '#00f0ff' : isPast ? '#4ade80' : '#475569',
                    }}
                  >
                    <span
                      className={`w-1.5 h-1.5 rounded-full ${isCurrent ? 'animate-pulse' : ''}`}
                      style={{ background: isCurrent ? '#00f0ff' : isActive ? '#4ade80' : '#334155' }}
                    />
                    {item.label}
                  </div>
                  {i < 2 && <div className="w-6 h-px" style={{ background: '#334155' }} />}
                </div>
              );
            })}
          </div>

          <div className="flex items-center gap-2 text-xs font-jetbrains" style={{ color: '#475569' }}>
            <div className="w-2 h-2 rounded-full" style={{ background: '#4ade80' }} />
            ENGINE: ONLINE
          </div>
        </div>
      </div>
    </header>
  );
}

function LandingHero() {
  return (
    <div className="text-center mb-16 relative">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[400px] bg-gradient-to-r from-cyan-500/10 via-purple-500/10 to-pink-500/10 rounded-full blur-[100px] pointer-events-none" />

      <div className="relative">
        <div className="inline-flex items-center gap-2 px-5 py-2 rounded-full border border-cyan-500/20 bg-cyan-500/5 text-xs font-orbitron tracking-widest mb-8 animate-float" style={{ color: '#00f0ff' }}>
          <Zap className="w-3 h-3" />
          POWERED BY AI + COMPUTER VISION
        </div>

        <h1 className="font-orbitron text-4xl md:text-6xl lg:text-7xl font-black mb-6 leading-tight">
          <span className="block text-white">Video To</span>
          <span className="block bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
            Playable Game
          </span>
          <span className="block text-white text-3xl md:text-5xl mt-2 font-bold">
            Reconstruction Engine
          </span>
        </h1>

        <p className="text-slate-400 max-w-3xl mx-auto text-lg mb-10 leading-relaxed">
          Upload any gameplay video. Our AI analyzes every frame using TensorFlow, OpenCV, and MediaPipe
          to reverse-engineer mechanics, environments, and controls — then rebuilds it as a playable prototype.
        </p>

        <div className="flex flex-wrap justify-center gap-3 mb-12">
          {[
            { icon: <Cpu className="w-3.5 h-3.5" />, label: 'TensorFlow' },
            { icon: <Eye className="w-3.5 h-3.5" />, label: 'OpenCV' },
            { icon: <Layers className="w-3.5 h-3.5" />, label: 'MediaPipe' },
            { icon: <Braces className="w-3.5 h-3.5" />, label: 'Three.js' },
            { icon: <Shield className="w-3.5 h-3.5" />, label: 'FFmpeg' },
            { icon: <Zap className="w-3.5 h-3.5" />, label: 'Node.js' },
          ].map(tech => (
            <div
              key={tech.label}
              className="flex items-center gap-2 px-4 py-2 rounded-lg text-slate-400 text-sm transition cursor-default"
              style={{ background: 'rgba(30,41,59,0.4)', border: '1px solid rgba(51,65,85,0.4)' }}
            >
              {tech.icon}
              {tech.label}
            </div>
          ))}
        </div>

        <div className="grid md:grid-cols-3 gap-4 max-w-4xl mx-auto mb-12">
          {[
            { title: 'Deep Video Analysis', desc: 'Frame-by-frame AI analysis detects gameplay mechanics, objects, animations, and visual patterns', icon: '🔍', color: '#00f0ff' },
            { title: 'Automatic Reconstruction', desc: 'AI code generation engine rebuilds detected gameplay systems into functional, playable prototypes', icon: '⚡', color: '#a78bfa' },
            { title: 'Playable Output', desc: 'Get a working game prototype with controls, physics, obstacles, collectibles, and proper game feel', icon: '🎮', color: '#f472b6' },
          ].map(feature => (
            <div key={feature.title} className="card p-6 text-left">
              <div className="text-3xl mb-4">{feature.icon}</div>
              <h3 className="font-orbitron text-sm tracking-wider mb-2" style={{ color: feature.color }}>
                {feature.title}
              </h3>
              <p className="text-sm text-slate-500 leading-relaxed">{feature.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function Footer() {
  return (
    <footer className="relative z-10 border-t border-slate-800/50 backdrop-blur-sm mt-20" style={{ background: 'rgba(15,23,42,0.2)' }}>
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-500 to-purple-600 flex items-center justify-center">
              <Zap className="w-4 h-4 text-white" />
            </div>
            <div>
              <span className="font-orbitron text-sm">
                <span style={{ color: '#00f0ff' }}>GAME</span>
                <span className="text-white">FORGE</span>
                <span style={{ color: '#a78bfa' }} className="ml-1">AI</span>
              </span>
              <p className="text-[9px] text-slate-600">Video To Game Reconstruction Engine</p>
            </div>
          </div>

          <div className="text-center">
            <p className="text-xs text-slate-600">
              Powered by TensorFlow • OpenCV • MediaPipe • Three.js • FFmpeg
            </p>
            <p className="text-[10px] text-slate-700 mt-1">
              AI-assisted game prototyping platform • All generated assets are original placeholders
            </p>
          </div>

          <div className="flex items-center gap-4">
            <Globe className="w-4 h-4 text-slate-600 cursor-pointer" />
            <Globe className="w-4 h-4 text-slate-600 cursor-pointer" />
            <Globe className="w-4 h-4 text-slate-600 cursor-pointer" />
          </div>
        </div>
      </div>
    </footer>
  );
}

export default function App() {
  const [step, setStep] = useState<AppStep>('upload');
  const [video, setVideo] = useState<VideoFile | null>(null);
  const [, setProject] = useState<ProjectFile | null>(null);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);

  const handleAnalyze = useCallback((v: VideoFile, p: ProjectFile | null) => {
    setVideo(v);
    setProject(p);
    setStep('analyzing');
  }, []);

  const handleAnalysisComplete = useCallback((result: AnalysisResult) => {
    setAnalysisResult(result);
    setStep('results');
  }, []);

  const handleReset = useCallback(() => {
    setStep('upload');
    setVideo(null);
    setProject(null);
    setAnalysisResult(null);
  }, []);

  return (
    <div className="min-h-screen bg-grid hex-pattern relative">
      <ParticleField />
      <div className="scan-line" />

      <Header step={step} />

      <main className="relative z-10 px-4 md:px-6 py-8 md:py-12">
        {step === 'upload' && (
          <div>
            <LandingHero />
            <UploadSection onAnalyze={handleAnalyze} />
          </div>
        )}

        {step === 'analyzing' && video && (
          <AnalysisPipeline video={video} onComplete={handleAnalysisComplete} />
        )}

        {step === 'results' && analysisResult && (
          <Dashboard result={analysisResult} onReset={handleReset} />
        )}
      </main>

      <Footer />
    </div>
  );
}
